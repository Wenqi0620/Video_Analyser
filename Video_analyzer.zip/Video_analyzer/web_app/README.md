# 视频分析Web平台

一个集成了视频分析和日历管理的全栈Web应用。

## 功能特性

### 视频分析
- ✅ 支持拖拽上传视频文件
- ✅ 自动分析视频的FPS、分辨率、时长等基础信息
- ✅ FPS动态变化分析
- ✅ 运动质量分析（4个核心指标）
- ✅ 自动归类视频到对应的生成模型（Gen-2、Pika、Haiper等）
- ✅ 实时查看分析进度和结果

### 日历集成
- ✅ 飞书日历集成
- ✅ Microsoft Outlook日历集成
- ✅ iCalendar格式支持
- ✅ 创建和管理日历事件

## 技术栈

### 后端
- **FastAPI** - 现代Python Web框架
- **SQLAlchemy** - ORM数据库操作
- **OpenCV** - 视频处理
- **FFmpeg** - 视频分析

### 前端
- **React 18** - UI框架
- **Ant Design** - UI组件库
- **Vite** - 构建工具
- **Axios** - HTTP客户端

## 快速开始

### 1. 安装后端依赖

```bash
cd web_app
pip install -r requirements_web.txt
```

### 2. 安装前端依赖

```bash
cd frontend
npm install
```

### 3. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 文件，填入你的配置
```

### 4. 初始化数据库

```bash
cd web_app
python -c "from app.database import init_db; init_db()"
```

### 5. 启动后端服务

```bash
cd web_app
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 6. 启动前端开发服务器

```bash
cd frontend
npm run dev
```

访问 http://localhost:3000 查看应用。

## Docker部署

### 使用Docker Compose

```bash
cd web_app
docker-compose up -d
```

### 手动构建Docker镜像

```bash
cd web_app
docker build -t video-analysis-platform .
docker run -p 8000:8000 video-analysis-platform
```

## 生产环境部署

### 使用Nginx反向代理

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # 前端静态文件
    location / {
        root /path/to/web_app/static;
        try_files $uri $uri/ /index.html;
    }

    # API代理
    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### 使用Gunicorn（生产环境）

```bash
pip install gunicorn
gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

## API文档

启动服务后，访问 http://localhost:8000/docs 查看自动生成的API文档。

### 主要API端点

- `POST /api/videos/upload` - 上传视频
- `GET /api/videos` - 获取视频列表
- `GET /api/videos/{video_id}` - 获取视频详情
- `GET /api/models` - 获取模型列表
- `GET /api/calendar/providers` - 获取日历提供商
- `POST /api/calendar/feishu/connect` - 连接飞书日历
- `POST /api/calendar/outlook/connect` - 连接Outlook日历
- `GET /api/calendar/events` - 获取日历事件
- `POST /api/calendar/events` - 创建日历事件

## 日历API配置

### 飞书日历

1. 访问 [飞书开放平台](https://open.feishu.cn/)
2. 创建应用，获取 App ID 和 App Secret
3. 在应用中启用"日历"权限
4. 在Web界面中填入凭证连接

### Outlook日历

1. 访问 [Azure Portal](https://portal.azure.com/)
2. 注册应用，获取 Client ID、Client Secret 和 Tenant ID
3. 配置API权限：`Calendars.ReadWrite`
4. 在Web界面中填入凭证连接

## 项目结构

```
web_app/
├── app/
│   ├── main.py              # FastAPI主应用
│   ├── database.py          # 数据库配置
│   ├── models.py            # 数据模型
│   ├── calendar_integration.py  # 日历集成
│   └── video_classifier.py  # 视频分类器
├── frontend/
│   ├── src/
│   │   ├── components/      # React组件
│   │   ├── services/        # API服务
│   │   └── App.jsx          # 主应用组件
│   └── package.json
├── uploads/                 # 上传的视频文件
├── results/                 # 分析结果
├── requirements_web.txt     # Python依赖
├── Dockerfile              # Docker配置
└── docker-compose.yml      # Docker Compose配置
```

## 开发指南

### 添加新的视频分析功能

1. 在 `video_analyzer.py` 中添加新的分析方法
2. 在 `app/main.py` 中添加对应的API端点
3. 在前端组件中集成新功能

### 添加新的日历提供商

1. 在 `app/calendar_integration.py` 中实现新的提供商类
2. 在 `app/main.py` 中添加对应的API端点
3. 在前端添加配置界面

## 常见问题

### Q: 视频分析失败怎么办？

A: 检查以下几点：
- 确保安装了FFmpeg：`brew install ffmpeg` (macOS) 或 `apt-get install ffmpeg` (Linux)
- 确保安装了OpenCV：`pip install opencv-python`
- 查看后端日志获取详细错误信息

### Q: 如何增加上传文件大小限制？

A: 在 `app/main.py` 中修改FastAPI的配置，或使用Nginx等反向代理配置。

### Q: 数据库可以换成PostgreSQL吗？

A: 可以，修改 `app/database.py` 中的 `DATABASE_URL`，并安装PostgreSQL驱动。

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request！

