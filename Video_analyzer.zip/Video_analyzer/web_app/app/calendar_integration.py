#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日历集成模块 - 支持飞书、Outlook、iCalendar
"""

import os
import json
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import httpx
from icalendar import Calendar, Event
import msal  # Microsoft Authentication Library


class CalendarManager:
    """日历管理器，支持多个日历服务提供商"""
    
    def __init__(self):
        self.feishu_token = None
        self.outlook_token = None
        self.outlook_app = None
        self.config = {
            "feishu": {
                "base_url": "https://open.feishu.cn/open-apis"
            },
            "outlook": {
                "base_url": "https://graph.microsoft.com/v1.0"
            }
        }
    
    # ========== 飞书日历 ==========
    
    async def connect_feishu(self, app_id: str, app_secret: str) -> Dict:
        """
        连接飞书日历
        
        Args:
            app_id: 飞书应用ID
            app_secret: 飞书应用密钥
            
        Returns:
            连接结果
        """
        try:
            # 获取tenant_access_token
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.config['feishu']['base_url']}/auth/v3/tenant_access_token/internal",
                    json={
                        "app_id": app_id,
                        "app_secret": app_secret
                    }
                )
                response.raise_for_status()
                data = response.json()
                
                if data.get("code") == 0:
                    self.feishu_token = data.get("tenant_access_token")
                    return {
                        "success": True,
                        "message": "飞书日历连接成功",
                        "provider": "feishu"
                    }
                else:
                    raise Exception(f"飞书认证失败: {data.get('msg', '未知错误')}")
                    
        except Exception as e:
            return {
                "success": False,
                "message": f"连接失败: {str(e)}",
                "provider": "feishu"
            }
    
    async def get_feishu_events(
        self, 
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict]:
        """
        获取飞书日历事件
        
        Args:
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)
            
        Returns:
            事件列表
        """
        if not self.feishu_token:
            raise Exception("未连接飞书日历，请先调用connect_feishu")
        
        # 默认查询未来7天
        if not start_date:
            start_date = datetime.now().strftime("%Y-%m-%d")
        if not end_date:
            end_date = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
        
        try:
            async with httpx.AsyncClient() as client:
                # 获取日历列表
                calendar_list_response = await client.get(
                    f"{self.config['feishu']['base_url']}/calendar/v4/calendars",
                    headers={
                        "Authorization": f"Bearer {self.feishu_token}"
                    }
                )
                calendar_list_response.raise_for_status()
                calendar_data = calendar_list_response.json()
                
                if calendar_data.get("code") != 0:
                    raise Exception(f"获取日历列表失败: {calendar_data.get('msg')}")
                
                calendars = calendar_data.get("data", {}).get("calendar_list", [])
                all_events = []
                
                # 遍历每个日历获取事件
                for calendar in calendars:
                    calendar_id = calendar.get("calendar_id")
                    if not calendar_id:
                        continue
                    
                    # 获取该日历的事件
                    events_response = await client.get(
                        f"{self.config['feishu']['base_url']}/calendar/v4/calendars/{calendar_id}/events",
                        headers={
                            "Authorization": f"Bearer {self.feishu_token}"
                        },
                        params={
                            "start_time": f"{start_date}T00:00:00+08:00",
                            "end_time": f"{end_date}T23:59:59+08:00"
                        }
                    )
                    events_response.raise_for_status()
                    events_data = events_response.json()
                    
                    if events_data.get("code") == 0:
                        events = events_data.get("data", {}).get("items", [])
                        for event in events:
                            all_events.append({
                                "id": event.get("event_id"),
                                "title": event.get("summary"),
                                "start": event.get("start_time", {}).get("date"),
                                "end": event.get("end_time", {}).get("date"),
                                "description": event.get("description"),
                                "location": event.get("location"),
                                "calendar": calendar.get("summary", "默认日历"),
                                "provider": "feishu"
                            })
                
                return all_events
                
        except Exception as e:
            raise Exception(f"获取飞书日历事件失败: {str(e)}")
    
    async def create_feishu_event(
        self,
        title: str,
        start_time: str,
        end_time: str,
        description: Optional[str] = None,
        location: Optional[str] = None
    ) -> Dict:
        """
        创建飞书日历事件
        
        Args:
            title: 事件标题
            start_time: 开始时间 (ISO格式)
            end_time: 结束时间 (ISO格式)
            description: 描述
            location: 地点
            
        Returns:
            创建的事件信息
        """
        if not self.feishu_token:
            raise Exception("未连接飞书日历")
        
        try:
            async with httpx.AsyncClient() as client:
                # 获取默认日历ID
                calendar_list_response = await client.get(
                    f"{self.config['feishu']['base_url']}/calendar/v4/calendars",
                    headers={
                        "Authorization": f"Bearer {self.feishu_token}"
                    }
                )
                calendar_list_response.raise_for_status()
                calendar_data = calendar_list_response.json()
                
                if calendar_data.get("code") != 0:
                    raise Exception("获取日历列表失败")
                
                calendars = calendar_data.get("data", {}).get("calendar_list", [])
                if not calendars:
                    raise Exception("未找到可用日历")
                
                calendar_id = calendars[0].get("calendar_id")
                
                # 创建事件
                event_data = {
                    "summary": title,
                    "start_time": {
                        "date": start_time
                    },
                    "end_time": {
                        "date": end_time
                    }
                }
                
                if description:
                    event_data["description"] = description
                if location:
                    event_data["location"] = location
                
                create_response = await client.post(
                    f"{self.config['feishu']['base_url']}/calendar/v4/calendars/{calendar_id}/events",
                    headers={
                        "Authorization": f"Bearer {self.feishu_token}",
                        "Content-Type": "application/json"
                    },
                    json=event_data
                )
                create_response.raise_for_status()
                result = create_response.json()
                
                if result.get("code") == 0:
                    return {
                        "success": True,
                        "event": result.get("data", {}).get("event"),
                        "provider": "feishu"
                    }
                else:
                    raise Exception(f"创建事件失败: {result.get('msg')}")
                    
        except Exception as e:
            raise Exception(f"创建飞书日历事件失败: {str(e)}")
    
    # ========== Outlook日历 ==========
    
    async def connect_outlook(
        self,
        client_id: str,
        client_secret: str,
        tenant_id: str
    ) -> Dict:
        """
        连接Outlook日历
        
        Args:
            client_id: Azure应用客户端ID
            client_secret: 客户端密钥
            tenant_id: 租户ID
            
        Returns:
            连接结果
        """
        try:
            # 使用MSAL进行认证
            authority = f"https://login.microsoftonline.com/{tenant_id}"
            app = msal.ConfidentialClientApplication(
                client_id,
                authority=authority,
                client_credential=client_secret
            )
            
            # 获取token（客户端凭证流）
            result = app.acquire_token_for_client(
                scopes=["https://graph.microsoft.com/.default"]
            )
            
            if "access_token" in result:
                self.outlook_token = result["access_token"]
                self.outlook_app = app
                return {
                    "success": True,
                    "message": "Outlook日历连接成功",
                    "provider": "outlook"
                }
            else:
                raise Exception(f"Outlook认证失败: {result.get('error_description', '未知错误')}")
                
        except Exception as e:
            return {
                "success": False,
                "message": f"连接失败: {str(e)}",
                "provider": "outlook"
            }
    
    async def get_outlook_events(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict]:
        """
        获取Outlook日历事件
        
        Args:
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)
            
        Returns:
            事件列表
        """
        if not self.outlook_token:
            raise Exception("未连接Outlook日历")
        
        # 默认查询未来7天
        if not start_date:
            start_date = datetime.now().strftime("%Y-%m-%dT00:00:00")
        else:
            start_date = f"{start_date}T00:00:00"
        
        if not end_date:
            end_date = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%dT23:59:59")
        else:
            end_date = f"{end_date}T23:59:59"
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.config['outlook']['base_url']}/me/calendar/calendarView",
                    headers={
                        "Authorization": f"Bearer {self.outlook_token}"
                    },
                    params={
                        "startDateTime": start_date,
                        "endDateTime": end_date,
                        "$orderby": "start/dateTime"
                    }
                )
                response.raise_for_status()
                data = response.json()
                
                events = []
                for item in data.get("value", []):
                    events.append({
                        "id": item.get("id"),
                        "title": item.get("subject"),
                        "start": item.get("start", {}).get("dateTime"),
                        "end": item.get("end", {}).get("dateTime"),
                        "description": item.get("body", {}).get("content"),
                        "location": item.get("location", {}).get("displayName"),
                        "provider": "outlook"
                    })
                
                return events
                
        except Exception as e:
            raise Exception(f"获取Outlook日历事件失败: {str(e)}")
    
    async def create_outlook_event(
        self,
        title: str,
        start_time: str,
        end_time: str,
        description: Optional[str] = None,
        location: Optional[str] = None
    ) -> Dict:
        """
        创建Outlook日历事件
        
        Args:
            title: 事件标题
            start_time: 开始时间 (ISO格式)
            end_time: 结束时间 (ISO格式)
            description: 描述
            location: 地点
            
        Returns:
            创建的事件信息
        """
        if not self.outlook_token:
            raise Exception("未连接Outlook日历")
        
        try:
            event_data = {
                "subject": title,
                "start": {
                    "dateTime": start_time,
                    "timeZone": "UTC"
                },
                "end": {
                    "dateTime": end_time,
                    "timeZone": "UTC"
                }
            }
            
            if description:
                event_data["body"] = {
                    "contentType": "HTML",
                    "content": description
                }
            
            if location:
                event_data["location"] = {
                    "displayName": location
                }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.config['outlook']['base_url']}/me/calendar/events",
                    headers={
                        "Authorization": f"Bearer {self.outlook_token}",
                        "Content-Type": "application/json"
                    },
                    json=event_data
                )
                response.raise_for_status()
                result = response.json()
                
                return {
                    "success": True,
                    "event": result,
                    "provider": "outlook"
                }
                
        except Exception as e:
            raise Exception(f"创建Outlook日历事件失败: {str(e)}")
    
    # ========== iCalendar (通用) ==========
    
    async def parse_icalendar(self, ical_content: str) -> List[Dict]:
        """
        解析iCalendar格式内容
        
        Args:
            ical_content: iCalendar格式的字符串内容
            
        Returns:
            事件列表
        """
        try:
            calendar = Calendar.from_ical(ical_content)
            events = []
            
            for component in calendar.walk():
                if component.name == "VEVENT":
                    event = {
                        "id": str(component.get("UID", "")),
                        "title": str(component.get("SUMMARY", "")),
                        "start": component.get("DTSTART").dt.isoformat() if component.get("DTSTART") else None,
                        "end": component.get("DTEND").dt.isoformat() if component.get("DTEND") else None,
                        "description": str(component.get("DESCRIPTION", "")),
                        "location": str(component.get("LOCATION", "")),
                        "provider": "icalendar"
                    }
                    events.append(event)
            
            return events
            
        except Exception as e:
            raise Exception(f"解析iCalendar失败: {str(e)}")
    
    async def create_icalendar_event(
        self,
        title: str,
        start_time: str,
        end_time: str,
        description: Optional[str] = None,
        location: Optional[str] = None
    ) -> str:
        """
        创建iCalendar格式的事件
        
        Args:
            title: 事件标题
            start_time: 开始时间 (ISO格式)
            end_time: 结束时间 (ISO格式)
            description: 描述
            location: 地点
            
        Returns:
            iCalendar格式的字符串
        """
        try:
            cal = Calendar()
            cal.add('prodid', '-//Video Analysis Platform//EN')
            cal.add('version', '2.0')
            
            event = Event()
            event.add('summary', title)
            event.add('dtstart', datetime.fromisoformat(start_time.replace('Z', '+00:00')))
            event.add('dtend', datetime.fromisoformat(end_time.replace('Z', '+00:00')))
            
            if description:
                event.add('description', description)
            if location:
                event.add('location', location)
            
            event.add('uid', f"{datetime.now().timestamp()}@video-analysis")
            
            cal.add_component(event)
            
            return cal.to_ical().decode('utf-8')
            
        except Exception as e:
            raise Exception(f"创建iCalendar事件失败: {str(e)}")
    
    # ========== 统一接口 ==========
    
    async def get_events(
        self,
        provider: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict]:
        """
        统一接口：获取日历事件
        
        Args:
            provider: 提供商 ('feishu', 'outlook', 'icalendar')
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            事件列表
        """
        if provider == "feishu":
            return await self.get_feishu_events(start_date, end_date)
        elif provider == "outlook":
            return await self.get_outlook_events(start_date, end_date)
        else:
            raise Exception(f"不支持的提供商: {provider}")
    
    async def create_event(
        self,
        provider: str,
        title: str,
        start_time: str,
        end_time: str,
        description: Optional[str] = None,
        location: Optional[str] = None
    ) -> Dict:
        """
        统一接口：创建日历事件
        
        Args:
            provider: 提供商 ('feishu', 'outlook', 'icalendar')
            title: 事件标题
            start_time: 开始时间
            end_time: 结束时间
            description: 描述
            location: 地点
            
        Returns:
            创建结果
        """
        if provider == "feishu":
            return await self.create_feishu_event(title, start_time, end_time, description, location)
        elif provider == "outlook":
            return await self.create_outlook_event(title, start_time, end_time, description, location)
        elif provider == "icalendar":
            ical_content = await self.create_icalendar_event(title, start_time, end_time, description, location)
            return {
                "success": True,
                "icalendar": ical_content,
                "provider": "icalendar"
            }
        else:
            raise Exception(f"不支持的提供商: {provider}")

