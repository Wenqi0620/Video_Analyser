#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频分类器 - 根据视频特征自动归类到对应的模型
"""

import re
from pathlib import Path
from typing import Dict, Optional


class VideoClassifier:
    """视频分类器，根据文件名和特征识别视频生成模型"""
    
    def __init__(self):
        # 模型识别规则（基于文件名模式）
        self.model_patterns = {
            "Gen-2": [
                r"gen-2",
                r"runway",
                r"gen2"
            ],
            "Pika": [
                r"pika",
                r"pika\.ai"
            ],
            "Haiper": [
                r"haiper"
            ],
            "Pixverse": [
                r"pixverse"
            ],
            "即梦": [
                r"即梦",
                r"jimeng"
            ],
            "可灵": [
                r"可灵",
                r"kling"
            ],
            "Stable Video Diffusion": [
                r"stable.*video",
                r"svd"
            ],
            "AnimateDiff": [
                r"animatediff",
                r"animate.*diff"
            ],
            "其他": []  # 默认分类
        }
    
    def classify(self, file_path: str, analysis_result: Dict) -> str:
        """
        分类视频到对应的模型
        
        Args:
            file_path: 视频文件路径
            analysis_result: 视频分析结果
            
        Returns:
            模型名称
        """
        filename = Path(file_path).name.lower()
        
        # 基于文件名模式匹配
        for model_name, patterns in self.model_patterns.items():
            for pattern in patterns:
                if re.search(pattern, filename, re.IGNORECASE):
                    return model_name
        
        # 如果无法从文件名识别，尝试基于特征推断
        # 这里可以根据分析结果的特征（如分辨率、FPS等）进行推断
        # 例如：某些模型通常生成特定分辨率的视频
        
        resolution = analysis_result.get("resolution", {})
        width = resolution.get("width", 0)
        height = resolution.get("height", 0)
        fps = analysis_result.get("fps", 0)
        
        # 基于分辨率的推断规则（示例）
        if width == 1024 and height == 576:
            # 某些模型常用这个分辨率
            return "Gen-2"
        elif width == 1280 and height == 720:
            return "Pika"
        
        # 默认返回"其他"
        return "其他"
    
    def get_model_list(self) -> list:
        """
        获取所有支持的模型列表
        
        Returns:
            模型名称列表
        """
        return list(self.model_patterns.keys())
    
    def add_model_pattern(self, model_name: str, pattern: str):
        """
        添加新的模型识别模式
        
        Args:
            model_name: 模型名称
            pattern: 正则表达式模式
        """
        if model_name not in self.model_patterns:
            self.model_patterns[model_name] = []
        self.model_patterns[model_name].append(pattern)

