#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据模型定义
"""

from sqlalchemy import Column, String, DateTime, Enum as SQLEnum, Text
from app.database import Base
import enum
from datetime import datetime

class AnalysisStatus(enum.Enum):
    """分析状态枚举"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class VideoAnalysis(Base):
    """视频分析记录模型"""
    __tablename__ = "video_analyses"
    
    id = Column(String, primary_key=True, index=True)
    filename = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    model_name = Column(String, nullable=True, index=True)  # 归类到的模型名称
    status = Column(SQLEnum(AnalysisStatus), default=AnalysisStatus.PENDING)
    analysis_result = Column(Text, nullable=True)  # JSON格式的分析结果
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)

