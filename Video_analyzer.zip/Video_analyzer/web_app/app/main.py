#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频分析Web应用 - 主应用入口
"""

from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from typing import List, Optional
import os
import sys
import json
import shutil
from pathlib import Path
from datetime import datetime
import uuid

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from video_analyzer import VideoAnalyzer
from app.database import get_db, init_db
from app.models import VideoAnalysis, AnalysisStatus
try:
    from app.calendar_integration import CalendarManager
    from app.video_classifier import VideoClassifier
except ImportError as e:
    print(f"警告: 导入模块失败 {e}，某些功能可能不可用")
    CalendarManager = None
    VideoClassifier = None

# 创建FastAPI应用
app = FastAPI(
    title="视频分析平台",
    description="集成视频分析和日历管理的Web平台",
    version="1.0.0"
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应该限制具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 创建必要的目录
UPLOAD_DIR = Path("uploads")
RESULTS_DIR = Path("results")
UPLOAD_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

# 挂载静态文件（前端）
app.mount("/static", StaticFiles(directory="web_app/static"), name="static")

# 初始化数据库
@app.on_event("startup")
async def startup_event():
    init_db()

# 依赖注入
def get_calendar_manager():
    if CalendarManager is None:
        raise HTTPException(status_code=503, detail="日历功能未启用")
    return CalendarManager()

def get_video_classifier():
    if VideoClassifier is None:
        raise HTTPException(status_code=503, detail="视频分类功能未启用")
    return VideoClassifier()

# ========== 视频分析API ==========

@app.post("/api/videos/upload")
async def upload_video(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    db = Depends(get_db)
):
    """
    上传视频文件并开始分析
    """
    # 验证文件类型
    if not file.filename.endswith(('.mp4', '.avi', '.mov', '.mkv', '.webm')):
        raise HTTPException(status_code=400, detail="不支持的视频格式")
    
    # 生成唯一ID
    video_id = str(uuid.uuid4())
    file_extension = Path(file.filename).suffix
    saved_filename = f"{video_id}{file_extension}"
    file_path = UPLOAD_DIR / saved_filename
    
    # 保存文件
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"文件保存失败: {str(e)}")
    
    # 创建数据库记录
    video_record = VideoAnalysis(
        id=video_id,
        filename=file.filename,
        file_path=str(file_path),
        status=AnalysisStatus.PENDING,
        created_at=datetime.now()
    )
    db.add(video_record)
    db.commit()
    db.refresh(video_record)
    
    # 后台任务：分析视频
    background_tasks.add_task(analyze_video_task, video_id, str(file_path))
    
    return {
        "video_id": video_id,
        "filename": file.filename,
        "status": "pending",
        "message": "视频上传成功，分析中..."
    }

@app.get("/api/videos")
async def list_videos(
    skip: int = 0,
    limit: int = 100,
    model: Optional[str] = None,
    db = Depends(get_db)
):
    """
    获取视频列表
    """
    query = db.query(VideoAnalysis)
    
    if model:
        query = query.filter(VideoAnalysis.model_name == model)
    
    videos = query.order_by(VideoAnalysis.created_at.desc()).offset(skip).limit(limit).all()
    
    return {
        "total": query.count(),
        "videos": [
            {
                "id": v.id,
                "filename": v.filename,
                "model_name": v.model_name,
                "status": v.status.value,
                "created_at": v.created_at.isoformat(),
                "analysis_result": json.loads(v.analysis_result) if v.analysis_result else None
            }
            for v in videos
        ]
    }

@app.get("/api/videos/{video_id}")
async def get_video(video_id: str, db = Depends(get_db)):
    """
    获取单个视频的详细信息
    """
    video = db.query(VideoAnalysis).filter(VideoAnalysis.id == video_id).first()
    
    if not video:
        raise HTTPException(status_code=404, detail="视频不存在")
    
    return {
        "id": video.id,
        "filename": video.filename,
        "model_name": video.model_name,
        "status": video.status.value,
        "created_at": video.created_at.isoformat(),
        "analysis_result": json.loads(video.analysis_result) if video.analysis_result else None
    }

@app.get("/api/videos/{video_id}/download")
async def download_video(video_id: str, db = Depends(get_db)):
    """
    下载原始视频文件
    """
    video = db.query(VideoAnalysis).filter(VideoAnalysis.id == video_id).first()
    
    if not video:
        raise HTTPException(status_code=404, detail="视频不存在")
    
    file_path = Path(video.file_path)
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="视频文件不存在")
    
    return FileResponse(
        path=str(file_path),
        filename=video.filename,
        media_type="video/mp4"
    )

@app.delete("/api/videos/{video_id}")
async def delete_video(video_id: str, db = Depends(get_db)):
    """
    删除视频及其分析结果
    """
    video = db.query(VideoAnalysis).filter(VideoAnalysis.id == video_id).first()
    
    if not video:
        raise HTTPException(status_code=404, detail="视频不存在")
    
    # 删除文件
    file_path = Path(video.file_path)
    if file_path.exists():
        file_path.unlink()
    
    # 删除分析结果文件
    result_path = RESULTS_DIR / f"{video_id}.json"
    if result_path.exists():
        result_path.unlink()
    
    # 删除数据库记录
    db.delete(video)
    db.commit()
    
    return {"message": "视频已删除"}

@app.get("/api/models")
async def list_models(db = Depends(get_db)):
    """
    获取所有模型列表及其视频数量
    """
    from sqlalchemy import func
    
    models = db.query(
        VideoAnalysis.model_name,
        func.count(VideoAnalysis.id).label('count')
    ).filter(
        VideoAnalysis.model_name.isnot(None)
    ).group_by(VideoAnalysis.model_name).all()
    
    return {
        "models": [
            {"name": model[0], "count": model[1]}
            for model in models
        ]
    }

# ========== 日历集成API ==========

@app.get("/api/calendar/providers")
async def get_calendar_providers():
    """
    获取支持的日历服务提供商
    """
    return {
        "providers": [
            {"id": "feishu", "name": "飞书日历"},
            {"id": "outlook", "name": "Microsoft Outlook"},
            {"id": "icalendar", "name": "iCalendar (通用)"}
        ]
    }

@app.post("/api/calendar/feishu/connect")
async def connect_feishu_calendar(
    app_id: str,
    app_secret: str,
    calendar_manager: CalendarManager = Depends(get_calendar_manager)
):
    """
    连接飞书日历
    """
    try:
        result = await calendar_manager.connect_feishu(app_id, app_secret)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/calendar/outlook/connect")
async def connect_outlook_calendar(
    client_id: str,
    client_secret: str,
    tenant_id: str,
    calendar_manager: CalendarManager = Depends(get_calendar_manager)
):
    """
    连接Outlook日历
    """
    try:
        result = await calendar_manager.connect_outlook(client_id, client_secret, tenant_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/calendar/events")
async def get_calendar_events(
    provider: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    calendar_manager: CalendarManager = Depends(get_calendar_manager)
):
    """
    获取日历事件
    """
    try:
        events = await calendar_manager.get_events(provider, start_date, end_date)
        return {"events": events}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/calendar/events")
async def create_calendar_event(
    provider: str,
    title: str,
    start_time: str,
    end_time: str,
    description: Optional[str] = None,
    calendar_manager: CalendarManager = Depends(get_calendar_manager)
):
    """
    创建日历事件
    """
    try:
        event = await calendar_manager.create_event(
            provider, title, start_time, end_time, description
        )
        return event
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========== 后台任务 ==========

def analyze_video_task(video_id: str, file_path: str):
    """
    后台任务：分析视频
    """
    from app.database import SessionLocal
    
    db = SessionLocal()
    try:
        video = db.query(VideoAnalysis).filter(VideoAnalysis.id == video_id).first()
        if not video:
            return
        
        # 更新状态为处理中
        video.status = AnalysisStatus.PROCESSING
        db.commit()
        
        # 执行分析
        analyzer = VideoAnalyzer(file_path)
        
        # 基础分析
        basic_result = analyzer.analyze()
        
        # FPS动态分析（可选，耗时较长）
        fps_dynamics = None
        try:
            fps_dynamics = analyzer.analyze_fps_dynamics()
        except Exception as e:
            print(f"FPS动态分析失败: {e}")
        
        # 运动质量分析（可选）
        motion_quality = None
        try:
            motion_quality = analyzer.analyze_motion_quality(sample_rate=5)  # 降低采样率以加快速度
        except Exception as e:
            print(f"运动质量分析失败: {e}")
        
        # 归类视频到模型
        model_name = "其他"
        try:
            classifier = VideoClassifier()
            model_name = classifier.classify(file_path, basic_result)
        except Exception as e:
            print(f"视频分类失败: {e}")
        
        # 保存分析结果
        analysis_result = {
            "basic": basic_result,
            "fps_dynamics": fps_dynamics,
            "motion_quality": motion_quality,
            "analyzed_at": datetime.now().isoformat()
        }
        
        result_file = RESULTS_DIR / f"{video_id}.json"
        with open(result_file, "w", encoding="utf-8") as f:
            json.dump(analysis_result, f, ensure_ascii=False, indent=2)
        
        # 更新数据库
        video.status = AnalysisStatus.COMPLETED
        video.model_name = model_name
        video.analysis_result = json.dumps(analysis_result, ensure_ascii=False)
        db.commit()
        
    except Exception as e:
        # 更新状态为失败
        video.status = AnalysisStatus.FAILED
        video.analysis_result = json.dumps({"error": str(e)}, ensure_ascii=False)
        db.commit()
        print(f"视频分析失败: {e}")
    finally:
        db.close()

# ========== 健康检查 ==========

@app.get("/api/health")
async def health_check():
    """
    健康检查端点
    """
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/")
async def root():
    """
    根路径，返回前端页面
    """
    return FileResponse("web_app/static/index.html")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

