#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据库配置和初始化
"""

from sqlalchemy import create_engine, Column, String, DateTime, Enum as SQLEnum, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import enum
from datetime import datetime

# 数据库URL（SQLite，生产环境可改为PostgreSQL）
DATABASE_URL = "sqlite:///./video_analysis.db"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}  # SQLite需要
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    """获取数据库会话"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    """初始化数据库表"""
    Base.metadata.create_all(bind=engine)

