# 快速开始指南

## 5分钟快速启动

### 步骤1: 安装后端依赖

```bash
cd web_app
pip install -r requirements_web.txt
```

### 步骤2: 初始化数据库

```bash
python3 -c "from app.database import init_db; init_db()"
```

### 步骤3: 启动后端

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

后端将在 http://localhost:8000 启动

### 步骤4: 安装前端依赖（新终端）

```bash
cd web_app/frontend
npm install
```

### 步骤5: 启动前端

```bash
npm run dev
```

前端将在 http://localhost:3000 启动

## 使用说明

### 上传和分析视频

1. 访问 http://localhost:3000
2. 点击"视频分析"标签
3. 拖拽或点击上传视频文件
4. 等待分析完成（可在列表中查看进度）
5. 点击"查看详情"查看分析结果

### 连接日历

1. 点击"日历集成"标签
2. 选择日历提供商（飞书/Outlook）
3. 填入相应的凭证信息
4. 点击"连接"按钮
5. 连接成功后可以查看和创建日历事件

## 常见问题

### Q: 提示FFmpeg未安装？

**macOS:**
```bash
brew install ffmpeg
```

**Ubuntu/Debian:**
```bash
sudo apt-get install ffmpeg
```

**Windows:**
从 https://ffmpeg.org/download.html 下载并添加到PATH

### Q: 前端无法连接后端？

确保：
1. 后端服务正在运行（http://localhost:8000）
2. 检查浏览器控制台是否有错误
3. 确认CORS配置正确

### Q: 视频分析失败？

1. 检查视频文件格式是否支持（MP4, AVI, MOV, MKV, WEBM）
2. 查看后端日志获取详细错误信息
3. 确保有足够的磁盘空间

## 下一步

- 查看 [README.md](README.md) 了解完整功能
- 查看 [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) 了解生产环境部署
- 访问 http://localhost:8000/docs 查看API文档

