#!/bin/bash

# 启动脚本

echo "正在启动视频分析平台..."

# 检查Python环境
if ! command -v python3 &> /dev/null; then
    echo "错误: 未找到Python3"
    exit 1
fi

# 检查依赖
if [ ! -f "requirements_web.txt" ]; then
    echo "错误: 未找到requirements_web.txt"
    exit 1
fi

# 安装依赖（如果需要）
if [ ! -d ".venv" ]; then
    echo "创建虚拟环境..."
    python3 -m venv .venv
fi

source .venv/bin/activate

echo "安装Python依赖..."
pip install -r requirements_web.txt

# 初始化数据库
echo "初始化数据库..."
python3 -c "from app.database import init_db; init_db()"

# 创建必要的目录
mkdir -p uploads results

# 启动服务
echo "启动后端服务..."
uvicorn app.main:app --host 0.0.0.0 --port 8000 &

echo "后端服务已启动在 http://localhost:8000"
echo "API文档: http://localhost:8000/docs"
echo ""
echo "要启动前端，请运行:"
echo "  cd frontend && npm install && npm run dev"

wait

