# 部署指南

## 本地开发环境

### 1. 后端设置

```bash
# 进入web_app目录
cd web_app

# 创建虚拟环境
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 安装依赖
pip install -r requirements_web.txt

# 初始化数据库
python3 -c "from app.database import init_db; init_db()"

# 创建上传目录
mkdir -p uploads results

# 启动服务
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 2. 前端设置

```bash
# 进入frontend目录
cd frontend

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

访问 http://localhost:3000

## Docker部署

### 构建和运行

```bash
cd web_app

# 构建镜像
docker build -t video-analysis-platform .

# 运行容器
docker run -d \
  -p 8000:8000 \
  -v $(pwd)/uploads:/app/uploads \
  -v $(pwd)/results:/app/results \
  -v $(pwd)/video_analysis.db:/app/video_analysis.db \
  --name video-analysis \
  video-analysis-platform
```

### 使用Docker Compose

```bash
cd web_app
docker-compose up -d
```

## 生产环境部署

### 使用Nginx + Gunicorn

#### 1. 安装Gunicorn

```bash
pip install gunicorn
```

#### 2. 使用Gunicorn启动

```bash
gunicorn app.main:app \
  -w 4 \
  -k uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8000 \
  --access-logfile - \
  --error-logfile -
```

#### 3. Nginx配置

创建 `/etc/nginx/sites-available/video-analysis`:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    client_max_body_size 2G;  # 允许大文件上传

    # 前端静态文件
    location / {
        root /path/to/web_app/static;
        try_files $uri $uri/ /index.html;
    }

    # API代理
    location /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # 支持大文件上传
        proxy_request_buffering off;
        client_max_body_size 2G;
    }

    # 静态文件缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

启用配置：

```bash
sudo ln -s /etc/nginx/sites-available/video-analysis /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 使用Systemd服务

创建 `/etc/systemd/system/video-analysis.service`:

```ini
[Unit]
Description=Video Analysis Platform
After=network.target

[Service]
Type=notify
User=www-data
WorkingDirectory=/path/to/web_app
Environment="PATH=/path/to/web_app/.venv/bin"
ExecStart=/path/to/web_app/.venv/bin/gunicorn app.main:app \
    -w 4 \
    -k uvicorn.workers.UvicornWorker \
    --bind 127.0.0.1:8000 \
    --access-logfile /var/log/video-analysis/access.log \
    --error-logfile /var/log/video-analysis/error.log

[Install]
WantedBy=multi-user.target
```

启动服务：

```bash
sudo systemctl daemon-reload
sudo systemctl enable video-analysis
sudo systemctl start video-analysis
```

## 云平台部署

### Vercel / Netlify (前端)

1. 构建前端：
```bash
cd frontend
npm run build
```

2. 部署 `web_app/static` 目录到Vercel/Netlify

3. 配置API代理指向后端服务

### Railway / Render (后端)

1. 连接GitHub仓库
2. 设置环境变量
3. 配置启动命令：`uvicorn app.main:app --host 0.0.0.0 --port $PORT`

### AWS / GCP / Azure

#### AWS EC2

1. 启动EC2实例（推荐Ubuntu 22.04）
2. 安装依赖：
```bash
sudo apt update
sudo apt install -y python3-pip python3-venv nginx ffmpeg
```

3. 克隆项目并部署
4. 配置Nginx和Systemd服务

#### 使用ECS/Fargate

1. 构建Docker镜像并推送到ECR
2. 创建ECS任务定义
3. 配置负载均衡器

## 环境变量配置

创建 `.env` 文件：

```bash
# 数据库
DATABASE_URL=postgresql://user:password@localhost/video_analysis

# 飞书
FEISHU_APP_ID=your_app_id
FEISHU_APP_SECRET=your_app_secret

# Outlook
OUTLOOK_CLIENT_ID=your_client_id
OUTLOOK_CLIENT_SECRET=your_client_secret
OUTLOOK_TENANT_ID=your_tenant_id

# 服务器
HOST=0.0.0.0
PORT=8000

# 安全
SECRET_KEY=your-secret-key-here
```

## 性能优化

### 1. 使用PostgreSQL替代SQLite

```python
# app/database.py
DATABASE_URL = "postgresql://user:password@localhost/video_analysis"
```

### 2. 使用Redis缓存

```bash
pip install redis
```

### 3. 使用Celery处理后台任务

```bash
pip install celery
```

### 4. CDN加速静态资源

将前端静态文件部署到CDN（如Cloudflare、AWS CloudFront）

## 监控和日志

### 使用Sentry监控错误

```bash
pip install sentry-sdk[fastapi]
```

### 日志配置

在 `app/main.py` 中配置日志：

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler()
    ]
)
```

## 安全建议

1. **使用HTTPS**: 配置SSL证书（Let's Encrypt免费）
2. **环境变量**: 不要将敏感信息提交到代码仓库
3. **文件上传限制**: 限制文件类型和大小
4. **CORS配置**: 生产环境限制允许的域名
5. **数据库安全**: 使用强密码，限制访问IP
6. **定期备份**: 备份数据库和上传的文件

## 故障排查

### 检查服务状态

```bash
# 检查后端
curl http://localhost:8000/api/health

# 检查日志
tail -f /var/log/video-analysis/error.log
```

### 常见问题

1. **端口被占用**: 修改端口或停止占用进程
2. **权限问题**: 确保上传目录有写权限
3. **数据库连接失败**: 检查数据库配置和网络连接
4. **FFmpeg未安装**: `sudo apt install ffmpeg`

## 更新部署

```bash
# 拉取最新代码
git pull

# 更新依赖
pip install -r requirements_web.txt

# 重启服务
sudo systemctl restart video-analysis
```

