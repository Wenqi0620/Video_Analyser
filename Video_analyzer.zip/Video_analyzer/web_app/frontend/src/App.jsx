import React, { useState } from 'react'
import { Layout, Menu, theme } from 'antd'
import {
  VideoCameraOutlined,
  CalendarOutlined,
  DashboardOutlined,
  SettingOutlined
} from '@ant-design/icons'
import VideoAnalysis from './components/VideoAnalysis'
import CalendarIntegration from './components/CalendarIntegration'
import Dashboard from './components/Dashboard'
import './App.css'

const { Header, Content, Sider } = Layout

function App() {
  const [selectedKey, setSelectedKey] = useState('dashboard')
  const {
    token: { colorBgContainer },
  } = theme.useToken()

  const menuItems = [
    {
      key: 'dashboard',
      icon: <DashboardOutlined />,
      label: '仪表盘',
    },
    {
      key: 'video',
      icon: <VideoCameraOutlined />,
      label: '视频分析',
    },
    {
      key: 'calendar',
      icon: <CalendarOutlined />,
      label: '日历集成',
    },
  ]

  const renderContent = () => {
    switch (selectedKey) {
      case 'dashboard':
        return <Dashboard />
      case 'video':
        return <VideoAnalysis />
      case 'calendar':
        return <CalendarIntegration />
      default:
        return <Dashboard />
    }
  }

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        breakpoint="lg"
        collapsedWidth="0"
        style={{
          background: colorBgContainer,
        }}
      >
        <div className="logo" style={{ 
          height: 64, 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          fontSize: 20,
          fontWeight: 'bold',
          color: '#1890ff'
        }}>
          视频分析平台
        </div>
        <Menu
          mode="inline"
          selectedKeys={[selectedKey]}
          items={menuItems}
          onClick={({ key }) => setSelectedKey(key)}
        />
      </Sider>
      <Layout>
        <Header
          style={{
            padding: '0 24px',
            background: colorBgContainer,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <h1 style={{ margin: 0, fontSize: 20 }}>
            {selectedKey === 'dashboard' && '仪表盘'}
            {selectedKey === 'video' && '视频分析'}
            {selectedKey === 'calendar' && '日历集成'}
          </h1>
        </Header>
        <Content
          style={{
            margin: '24px 16px',
            padding: 24,
            minHeight: 280,
            background: colorBgContainer,
          }}
        >
          {renderContent()}
        </Content>
      </Layout>
    </Layout>
  )
}

export default App

