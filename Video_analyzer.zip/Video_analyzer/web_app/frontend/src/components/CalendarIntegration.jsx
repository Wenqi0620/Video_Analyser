import React, { useState, useEffect } from 'react'
import { 
  Card, 
  Tabs, 
  Form, 
  Input, 
  Button, 
  message, 
  Table, 
  Modal,
  Space,
  DatePicker,
  Select
} from 'antd'
import { 
  PlusOutlined,
  ReloadOutlined
} from '@ant-design/icons'
import dayjs from 'dayjs'
import api from '../services/api'

const { TabPane } = Tabs
const { TextArea } = Input
const { RangePicker } = DatePicker

function CalendarIntegration() {
  const [providers, setProviders] = useState([])
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(false)
  const [createModalVisible, setCreateModalVisible] = useState(false)
  const [createForm] = Form.useForm()
  const [feishuForm] = Form.useForm()
  const [outlookForm] = Form.useForm()

  useEffect(() => {
    loadProviders()
  }, [])

  const loadProviders = async () => {
    try {
      const response = await api.get('/calendar/providers')
      setProviders(response.data.providers || [])
    } catch (error) {
      console.error('加载日历提供商失败:', error)
    }
  }

  const loadEvents = async (provider) => {
    try {
      setLoading(true)
      const response = await api.get('/calendar/events', {
        params: { provider }
      })
      setEvents(response.data.events || [])
    } catch (error) {
      message.error('加载日历事件失败: ' + (error.response?.data?.detail || error.message))
    } finally {
      setLoading(false)
    }
  }

  const handleConnectFeishu = async (values) => {
    try {
      const response = await api.post('/calendar/feishu/connect', null, {
        params: {
          app_id: values.app_id,
          app_secret: values.app_secret
        }
      })
      if (response.data.success) {
        message.success('飞书日历连接成功')
        feishuForm.resetFields()
        loadEvents('feishu')
      } else {
        message.error(response.data.message)
      }
    } catch (error) {
      message.error('连接失败: ' + (error.response?.data?.detail || error.message))
    }
  }

  const handleConnectOutlook = async (values) => {
    try {
      const response = await api.post('/calendar/outlook/connect', null, {
        params: {
          client_id: values.client_id,
          client_secret: values.client_secret,
          tenant_id: values.tenant_id
        }
      })
      if (response.data.success) {
        message.success('Outlook日历连接成功')
        outlookForm.resetFields()
        loadEvents('outlook')
      } else {
        message.error(response.data.message)
      }
    } catch (error) {
      message.error('连接失败: ' + (error.response?.data?.detail || error.message))
    }
  }

  const handleCreateEvent = async (values) => {
    try {
      const provider = values.provider
      const response = await api.post('/calendar/events', null, {
        params: {
          provider,
          title: values.title,
          start_time: values.timeRange[0].toISOString(),
          end_time: values.timeRange[1].toISOString(),
          description: values.description,
          location: values.location
        }
      })
      message.success('事件创建成功')
      setCreateModalVisible(false)
      createForm.resetFields()
      loadEvents(provider)
    } catch (error) {
      message.error('创建事件失败: ' + (error.response?.data?.detail || error.message))
    }
  }

  const eventColumns = [
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title',
    },
    {
      title: '开始时间',
      dataIndex: 'start',
      key: 'start',
      render: (text) => text ? dayjs(text).format('YYYY-MM-DD HH:mm') : '-'
    },
    {
      title: '结束时间',
      dataIndex: 'end',
      key: 'end',
      render: (text) => text ? dayjs(text).format('YYYY-MM-DD HH:mm') : '-'
    },
    {
      title: '地点',
      dataIndex: 'location',
      key: 'location',
    },
    {
      title: '描述',
      dataIndex: 'description',
      key: 'description',
      ellipsis: true
    },
  ]

  return (
    <div>
      <Tabs defaultActiveKey="feishu">
        <TabPane tab="飞书日历" key="feishu">
          <Card title="连接飞书日历" style={{ marginBottom: 24 }}>
            <Form
              form={feishuForm}
              layout="vertical"
              onFinish={handleConnectFeishu}
            >
              <Form.Item
                name="app_id"
                label="应用ID (App ID)"
                rules={[{ required: true, message: '请输入应用ID' }]}
              >
                <Input placeholder="飞书应用ID" />
              </Form.Item>
              <Form.Item
                name="app_secret"
                label="应用密钥 (App Secret)"
                rules={[{ required: true, message: '请输入应用密钥' }]}
              >
                <Input.Password placeholder="飞书应用密钥" />
              </Form.Item>
              <Form.Item>
                <Button type="primary" htmlType="submit">
                  连接
                </Button>
                <Button 
                  style={{ marginLeft: 8 }}
                  onClick={() => loadEvents('feishu')}
                >
                  <ReloadOutlined /> 刷新事件
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </TabPane>

        <TabPane tab="Outlook日历" key="outlook">
          <Card title="连接Outlook日历" style={{ marginBottom: 24 }}>
            <Form
              form={outlookForm}
              layout="vertical"
              onFinish={handleConnectOutlook}
            >
              <Form.Item
                name="client_id"
                label="客户端ID (Client ID)"
                rules={[{ required: true, message: '请输入客户端ID' }]}
              >
                <Input placeholder="Azure应用客户端ID" />
              </Form.Item>
              <Form.Item
                name="client_secret"
                label="客户端密钥 (Client Secret)"
                rules={[{ required: true, message: '请输入客户端密钥' }]}
              >
                <Input.Password placeholder="Azure应用客户端密钥" />
              </Form.Item>
              <Form.Item
                name="tenant_id"
                label="租户ID (Tenant ID)"
                rules={[{ required: true, message: '请输入租户ID' }]}
              >
                <Input placeholder="Azure租户ID" />
              </Form.Item>
              <Form.Item>
                <Button type="primary" htmlType="submit">
                  连接
                </Button>
                <Button 
                  style={{ marginLeft: 8 }}
                  onClick={() => loadEvents('outlook')}
                >
                  <ReloadOutlined /> 刷新事件
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </TabPane>

        <TabPane tab="iCalendar" key="icalendar">
          <Card title="iCalendar支持">
            <p>iCalendar是通用的日历格式标准，支持导入和导出.ics文件。</p>
            <p>您可以使用任何支持iCalendar的日历应用（如Google Calendar、Apple Calendar等）导入事件。</p>
          </Card>
        </TabPane>
      </Tabs>

      <Card 
        title="日历事件"
        extra={
          <Button 
            type="primary" 
            icon={<PlusOutlined />}
            onClick={() => setCreateModalVisible(true)}
          >
            创建事件
          </Button>
        }
      >
        <Table
          columns={eventColumns}
          dataSource={events}
          loading={loading}
          rowKey="id"
          pagination={{ pageSize: 10 }}
        />
      </Card>

      <Modal
        title="创建日历事件"
        open={createModalVisible}
        onCancel={() => {
          setCreateModalVisible(false)
          createForm.resetFields()
        }}
        onOk={() => createForm.submit()}
      >
        <Form
          form={createForm}
          layout="vertical"
          onFinish={handleCreateEvent}
        >
          <Form.Item
            name="provider"
            label="日历提供商"
            rules={[{ required: true, message: '请选择日历提供商' }]}
          >
            <Select>
              <Select.Option value="feishu">飞书日历</Select.Option>
              <Select.Option value="outlook">Outlook日历</Select.Option>
              <Select.Option value="icalendar">iCalendar</Select.Option>
            </Select>
          </Form.Item>
          <Form.Item
            name="title"
            label="事件标题"
            rules={[{ required: true, message: '请输入事件标题' }]}
          >
            <Input placeholder="事件标题" />
          </Form.Item>
          <Form.Item
            name="timeRange"
            label="时间范围"
            rules={[{ required: true, message: '请选择时间范围' }]}
          >
            <RangePicker 
              showTime 
              style={{ width: '100%' }}
            />
          </Form.Item>
          <Form.Item
            name="location"
            label="地点"
          >
            <Input placeholder="地点（可选）" />
          </Form.Item>
          <Form.Item
            name="description"
            label="描述"
          >
            <TextArea rows={4} placeholder="事件描述（可选）" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default CalendarIntegration

