import React, { useState, useEffect } from 'react'
import { 
  Upload, 
  Card, 
  List, 
  Tag, 
  Button, 
  Progress, 
  Space, 
  Modal, 
  Descriptions,
  Empty,
  message,
  Select
} from 'antd'
import { 
  InboxOutlined, 
  DeleteOutlined, 
  EyeOutlined,
  DownloadOutlined 
} from '@ant-design/icons'
import { useDropzone } from 'react-dropzone'
import api from '../services/api'

const { Dragger } = Upload
const { Option } = Select

function VideoAnalysis() {
  const [videos, setVideos] = useState([])
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [selectedVideo, setSelectedVideo] = useState(null)
  const [detailModalVisible, setDetailModalVisible] = useState(false)
  const [filterModel, setFilterModel] = useState(null)
  const [models, setModels] = useState([])

  useEffect(() => {
    loadVideos()
    loadModels()
    // 轮询更新状态
    const interval = setInterval(() => {
      loadVideos()
    }, 3000)
    return () => clearInterval(interval)
  }, [filterModel])

  const loadVideos = async () => {
    try {
      setLoading(true)
      const params = filterModel ? { model: filterModel } : {}
      const response = await api.get('/videos', { params })
      setVideos(response.data.videos || [])
    } catch (error) {
      message.error('加载视频列表失败')
    } finally {
      setLoading(false)
    }
  }

  const loadModels = async () => {
    try {
      const response = await api.get('/models')
      setModels(response.data.models || [])
    } catch (error) {
      console.error('加载模型列表失败:', error)
    }
  }

  const handleUpload = async (file) => {
    const formData = new FormData()
    formData.append('file', file)
    
    try {
      setUploading(true)
      const response = await api.post('/videos/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      message.success('视频上传成功，正在分析...')
      loadVideos()
    } catch (error) {
      message.error('上传失败: ' + (error.response?.data?.detail || error.message))
    } finally {
      setUploading(false)
    }
  }

  const handleDelete = async (videoId) => {
    try {
      await api.delete(`/videos/${videoId}`)
      message.success('删除成功')
      loadVideos()
    } catch (error) {
      message.error('删除失败')
    }
  }

  const handleViewDetail = async (videoId) => {
    try {
      const response = await api.get(`/videos/${videoId}`)
      setSelectedVideo(response.data)
      setDetailModalVisible(true)
    } catch (error) {
      message.error('获取详情失败')
    }
  }

  const handleDownload = (videoId, filename) => {
    window.open(`/api/videos/${videoId}/download`, '_blank')
  }

  const getStatusTag = (status) => {
    const statusMap = {
      pending: { color: 'default', text: '等待中' },
      processing: { color: 'processing', text: '分析中' },
      completed: { color: 'success', text: '已完成' },
      failed: { color: 'error', text: '失败' }
    }
    const statusInfo = statusMap[status] || statusMap.pending
    return <Tag color={statusInfo.color}>{statusInfo.text}</Tag>
  }

  const uploadProps = {
    name: 'file',
    multiple: true,
    accept: 'video/*',
    beforeUpload: (file) => {
      handleUpload(file)
      return false // 阻止自动上传
    },
    showUploadList: false
  }

  return (
    <div>
      <Card 
        title="上传视频" 
        style={{ marginBottom: 24 }}
        extra={
          <Select
            placeholder="筛选模型"
            allowClear
            style={{ width: 200 }}
            onChange={setFilterModel}
            value={filterModel}
          >
            {models.map(model => (
              <Option key={model.name} value={model.name}>
                {model.name} ({model.count})
              </Option>
            ))}
          </Select>
        }
      >
        <Dragger {...uploadProps} disabled={uploading}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">点击或拖拽视频文件到此区域上传</p>
          <p className="ant-upload-hint">
            支持 MP4, AVI, MOV, MKV, WEBM 格式
          </p>
        </Dragger>
      </Card>

      <Card title="视频列表">
        {videos.length === 0 ? (
          <Empty description="暂无视频" />
        ) : (
          <List
            loading={loading}
            dataSource={videos}
            renderItem={(video) => (
              <List.Item
                actions={[
                  <Button
                    type="link"
                    icon={<EyeOutlined />}
                    onClick={() => handleViewDetail(video.id)}
                  >
                    查看详情
                  </Button>,
                  <Button
                    type="link"
                    icon={<DownloadOutlined />}
                    onClick={() => handleDownload(video.id, video.filename)}
                  >
                    下载
                  </Button>,
                  <Button
                    type="link"
                    danger
                    icon={<DeleteOutlined />}
                    onClick={() => handleDelete(video.id)}
                  >
                    删除
                  </Button>
                ]}
              >
                <List.Item.Meta
                  title={
                    <Space>
                      <span>{video.filename}</span>
                      {getStatusTag(video.status)}
                      {video.model_name && (
                        <Tag color="blue">{video.model_name}</Tag>
                      )}
                    </Space>
                  }
                  description={
                    <div>
                      <div>上传时间: {new Date(video.created_at).toLocaleString()}</div>
                      {(video.status === 'processing' || video.status === 'pending') && (
                        <Progress percent={50} status="active" size="small" style={{ marginTop: 8 }} />
                      )}
                    </div>
                  }
                />
              </List.Item>
            )}
          />
        )}
      </Card>

      <Modal
        title="视频分析详情"
        open={detailModalVisible}
        onCancel={() => setDetailModalVisible(false)}
        footer={null}
        width={800}
      >
        {selectedVideo && (
          <div>
            <Descriptions column={2} bordered>
              <Descriptions.Item label="文件名">{selectedVideo.filename}</Descriptions.Item>
              <Descriptions.Item label="状态">
                {getStatusTag(selectedVideo.status)}
              </Descriptions.Item>
              <Descriptions.Item label="模型">{selectedVideo.model_name || '未识别'}</Descriptions.Item>
              <Descriptions.Item label="上传时间">
                {new Date(selectedVideo.created_at).toLocaleString()}
              </Descriptions.Item>
            </Descriptions>

            {selectedVideo.analysis_result && (
              <div style={{ marginTop: 24 }}>
                <h3>分析结果</h3>
                <pre style={{ 
                  background: '#f5f5f5', 
                  padding: 16, 
                  borderRadius: 4,
                  maxHeight: 400,
                  overflow: 'auto'
                }}>
                  {JSON.stringify(selectedVideo.analysis_result, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  )
}

export default VideoAnalysis

