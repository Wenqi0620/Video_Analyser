import React, { useEffect, useState } from 'react'
import { Row, Col, Card, Statistic, Spin } from 'antd'
import { VideoCameraOutlined, CheckCircleOutlined, ClockCircleOutlined } from '@ant-design/icons'
import api from '../services/api'

function Dashboard() {
  const [stats, setStats] = useState({
    total: 0,
    completed: 0,
    processing: 0,
    models: []
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadStats()
  }, [])

  const loadStats = async () => {
    try {
      setLoading(true)
      const [videosRes, modelsRes] = await Promise.all([
        api.get('/videos?limit=1000'),
        api.get('/models')
      ])
      
      const videos = videosRes.data.videos || []
      const total = videos.length
      const completed = videos.filter(v => v.status === 'completed').length
      const processing = videos.filter(v => v.status === 'processing' || v.status === 'pending').length
      
      setStats({
        total,
        completed,
        processing,
        models: modelsRes.data.models || []
      })
    } catch (error) {
      console.error('加载统计数据失败:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
      </div>
    )
  }

  return (
    <div>
      <Row gutter={[16, 16]}>
        <Col xs={24} sm={12} lg={8}>
          <Card>
            <Statistic
              title="总视频数"
              value={stats.total}
              prefix={<VideoCameraOutlined />}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={8}>
          <Card>
            <Statistic
              title="已完成分析"
              value={stats.completed}
              prefix={<CheckCircleOutlined />}
              valueStyle={{ color: '#52c41a' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={8}>
          <Card>
            <Statistic
              title="处理中"
              value={stats.processing}
              prefix={<ClockCircleOutlined />}
              valueStyle={{ color: '#faad14' }}
            />
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginTop: 24 }}>
        <Col xs={24} lg={12}>
          <Card title="模型分布">
            {stats.models.length > 0 ? (
              <div>
                {stats.models.map(model => (
                  <div key={model.name} style={{ 
                    marginBottom: 12,
                    padding: '8px 12px',
                    background: '#f5f5f5',
                    borderRadius: 4,
                    display: 'flex',
                    justifyContent: 'space-between'
                  }}>
                    <span>{model.name}</span>
                    <span style={{ fontWeight: 'bold', color: '#1890ff' }}>
                      {model.count} 个视频
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ textAlign: 'center', color: '#8c8c8c', padding: '20px' }}>
                暂无数据
              </div>
            )}
          </Card>
        </Col>
      </Row>
    </div>
  )
}

export default Dashboard

