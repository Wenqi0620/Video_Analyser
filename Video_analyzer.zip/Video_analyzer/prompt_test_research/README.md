# Prompt测试研究文件夹

本文件夹包含用于系统化测试视频生成prompt的完整工具链。

## 📁 文件说明

### 核心文件

1. **`prompts_test_config.json`** - Prompt测试配置文件
   - 包含10个不同类别和难度的测试prompt
   - 定义了测试模型列表和评估指标

2. **`prompt_test_manager.py`** - Prompt测试管理工具
   - 创建测试计划
   - 管理视频映射文件
   - 验证测试进度

3. **`analyze_prompt_tests.py`** - 批量分析工具
   - 基于视频映射文件批量分析视频
   - 生成对比报告（CSV/Excel）
   - 按prompt和模型分组统计

### 文档文件

4. **`PROMPT_TEST_GUIDE.md`** - 详细使用指南
   - 完整的测试流程说明
   - 研究建议和最佳实践
   - 常见问题解答

5. **`PROMPT_TEST_QUICKSTART.md`** - 快速开始指南
   - 5步快速开始流程
   - 关键命令速查

## 🚀 快速开始

### 1. 查看测试配置

```bash
cd prompt_test_research
python prompt_test_manager.py summary
```

### 2. 创建测试计划

```bash
# 创建测试计划文档
python prompt_test_manager.py plan

# 创建视频映射模板
python prompt_test_manager.py template
```

### 3. 生成视频并填写映射

1. 使用各个模型生成视频
2. 编辑 `prompt_test_results/video_mapping.json`
3. 填写每个测试用例的视频路径

### 4. 验证并分析

```bash
# 验证映射文件
python prompt_test_manager.py validate prompt_test_results/video_mapping.json

# 批量分析所有视频
python analyze_prompt_tests.py prompt_test_results/video_mapping.json
```

### 5. 查看报告

分析完成后，在 `prompt_test_results/` 目录查看：
- CSV/Excel对比报告
- JSON详细数据

## 📊 测试Prompt列表

本文件夹包含10个测试prompt，涵盖：

- **自然场景**: 花朵绽放、海浪拍岸
- **镜头运动**: 镜头推进画作、无人机航拍
- **动作场景**: 拳头击碎地面
- **特效场景**: 传送门出现、火焰燃烧
- **城市场景**: 城市夜景车流
- **人物运动**: 人物行走
- **细节场景**: 雨滴落下

## 🔬 研究目标

使用这些工具可以研究：

1. **Prompt设计研究** - 哪些类型的prompt更容易生成高质量视频
2. **模型对比研究** - 不同模型在不同类型prompt上的表现
3. **Prompt-模型匹配研究** - 最佳prompt-模型组合
4. **质量指标相关性研究** - 哪些指标最能预测整体质量
5. **失败案例分析** - 低质量视频的原因和改进建议

## 📂 目录结构

```
prompt_test_research/
├── README.md                      # 本文件
├── prompts_test_config.json       # Prompt配置文件
├── prompt_test_manager.py         # 测试管理工具
├── analyze_prompt_tests.py        # 批量分析工具
├── PROMPT_TEST_GUIDE.md           # 详细指南
├── PROMPT_TEST_QUICKSTART.md       # 快速开始
└── prompt_test_results/           # 测试结果目录（自动创建）
    ├── 测试计划_*.md              # 测试计划文档
    ├── video_mapping.json         # 视频映射文件
    ├── prompt_test_results_*.json # 分析结果
    └── prompt_test_comparison_*.csv/xlsx  # 对比报告
```

## 🔗 相关文件

本工具依赖项目根目录的 `video_analyzer.py` 进行视频分析。

## 📝 注意事项

- 运行脚本时，请确保在 `prompt_test_research/` 目录下
- 视频文件可以放在任何位置，只需在映射文件中填写完整路径
- 分析过程可能需要较长时间，建议使用采样率参数加快速度

## 📚 更多信息

详细使用说明请参考：
- `PROMPT_TEST_GUIDE.md` - 完整使用指南
- `PROMPT_TEST_QUICKSTART.md` - 快速开始指南

---

**创建时间**: 2024-12-24  
**用途**: 系统化测试视频生成prompt的质量评估

