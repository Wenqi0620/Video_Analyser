# Prompt测试快速开始

## 🎯 目标

系统性地测试10个不同的视频生成prompt，评估不同模型生成视频的质量。

## 📦 已创建的文件

1. **`prompts_test_config.json`** - 包含10个测试prompt的配置
2. **`prompt_test_manager.py`** - Prompt测试管理工具
3. **`analyze_prompt_tests.py`** - 批量分析工具
4. **`PROMPT_TEST_GUIDE.md`** - 详细使用指南

## 🚀 5步快速开始

### 步骤1: 查看测试配置

```bash
python prompt_test_manager.py summary
```

这会显示：
- 10个测试prompt的列表
- 测试模型列表
- 总测试用例数量

### 步骤2: 创建测试计划

```bash
# 创建测试计划文档
python prompt_test_manager.py plan

# 创建视频映射模板
python prompt_test_manager.py template
```

### 步骤3: 生成视频并填写映射

1. 使用各个模型生成视频（Gen-2, Pika, Runway等）
2. 编辑 `prompt_test_results/video_mapping.json`
3. 填写每个测试用例的视频路径

### 步骤4: 验证并分析

```bash
# 验证映射文件
python prompt_test_manager.py validate prompt_test_results/video_mapping.json

# 批量分析所有视频
python analyze_prompt_tests.py prompt_test_results/video_mapping.json
```

### 步骤5: 查看报告

分析完成后，在 `prompt_test_results/` 目录查看：
- CSV/Excel对比报告
- JSON详细数据

## 📊 10个测试Prompt

1. **花朵绽放** - 自然场景，中等难度
2. **镜头推进画作** - 镜头运动，高难度
3. **拳头击碎地面** - 动作场景，高难度
4. **传送门出现** - 特效场景，高难度
5. **海浪拍岸** - 自然场景，中等难度
6. **城市夜景车流** - 城市场景，中等难度
7. **人物行走** - 人物运动，高难度
8. **火焰燃烧** - 特效场景，中等难度
9. **无人机航拍** - 镜头运动，高难度
10. **雨滴落下** - 细节场景，简单

## 🔬 研究建议

### 1. Prompt设计研究
- 哪些类型的prompt更容易生成高质量视频？
- 不同难度级别的prompt表现如何？
- 关键词（如"cinematic", "uhd"）的影响？

### 2. 模型对比研究
- 哪个模型整体表现最好？
- 不同模型在不同类型prompt上的表现？
- 模型的优势和劣势？

### 3. Prompt-模型匹配研究
- 哪些prompt-模型组合表现最好？
- 是否存在特定prompt适合特定模型？
- 如何为不同prompt选择最佳模型？

### 4. 质量指标相关性研究
- 哪些指标最能预测整体质量？
- 指标之间是否存在相关性？
- 哪些指标对特定类型prompt更重要？

### 5. 失败案例分析
- 哪些测试用例得分最低？为什么？
- 常见的问题类型有哪些？
- 如何改进低质量视频？

## 📈 评估指标

分析报告包含6个关键指标（总分100分）：

1. **FPS稳定性** (25分) - 帧率稳定性
2. **时间戳抖动** (15分) - 时间戳稳定性
3. **重复帧** (15分) - 重复帧检测
4. **运动连续性** (25分) - 运动平滑度
5. **果冻效应** (10分) - 滚动快门失真
6. **视频质量** (10分) - 分辨率评分

## 💡 提示

- **采样率**: 使用 `--sample-rate 5` 可以加快分析速度（默认值）
- **分批测试**: 如果视频很多，可以分批生成和分析
- **保存结果**: 分析过程较长，建议保存JSON结果作为备份

## 📚 详细文档

查看 `PROMPT_TEST_GUIDE.md` 获取完整的使用指南和最佳实践。

---

**开始你的测试之旅吧！** 🎬

