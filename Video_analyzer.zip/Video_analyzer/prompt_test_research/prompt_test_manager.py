#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prompt测试管理工具
用于组织和管理视频生成prompt的测试
"""

import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import csv

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False


class PromptTestManager:
    """Prompt测试管理器"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化测试管理器
        
        Args:
            config_path: prompt配置文件路径，如果为None则使用默认路径
        """
        if config_path is None:
            # 默认使用同目录下的配置文件
            self.config_path = Path(__file__).parent / "prompts_test_config.json"
        else:
            self.config_path = Path(config_path)
        self.config = self._load_config()
        # 结果目录放在当前目录下
        self.test_results_dir = Path(__file__).parent / "prompt_test_results"
        self.test_results_dir.mkdir(exist_ok=True)
        
    def _load_config(self) -> Dict:
        """加载配置文件"""
        if not self.config_path.exists():
            raise FileNotFoundError(
                f"配置文件不存在: {self.config_path}\n"
                f"请先创建配置文件，或使用默认配置。"
            )
        
        with open(self.config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def list_prompts(self) -> List[Dict]:
        """列出所有prompt"""
        return self.config.get('prompts', [])
    
    def get_prompt_by_id(self, prompt_id: str) -> Optional[Dict]:
        """根据ID获取prompt"""
        for prompt in self.config.get('prompts', []):
            if prompt.get('id') == prompt_id:
                return prompt
        return None
    
    def create_test_plan(self, output_path: Optional[str] = None) -> str:
        """
        创建测试计划文档
        
        Args:
            output_path: 输出文件路径，如果为None则使用默认路径
            
        Returns:
            输出文件路径
        """
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = self.test_results_dir / f"测试计划_{timestamp}.md"
        else:
            output_path = Path(output_path)
        
        prompts = self.list_prompts()
        models = self.config.get('models_to_test', [])
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(f"# {self.config.get('test_name', 'Prompt测试计划')}\n\n")
            f.write(f"**创建时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write(f"**描述**: {self.config.get('description', '')}\n\n")
            
            f.write("## 测试概览\n\n")
            f.write(f"- **Prompt数量**: {len(prompts)}\n")
            f.write(f"- **测试模型数量**: {len(models)}\n")
            f.write(f"- **总测试用例**: {len(prompts) * len(models)}\n\n")
            
            f.write("## Prompt列表\n\n")
            for i, prompt in enumerate(prompts, 1):
                f.write(f"### {i}. {prompt.get('name', '未命名')} (ID: {prompt.get('id', '')})\n\n")
                f.write(f"- **Prompt**: `{prompt.get('prompt', '')}`\n")
                f.write(f"- **类别**: {prompt.get('category', '未分类')}\n")
                f.write(f"- **难度**: {prompt.get('difficulty', '未知')}\n")
                f.write(f"- **预期特征**: {', '.join(prompt.get('expected_characteristics', []))}\n\n")
            
            f.write("## 测试模型\n\n")
            for model in models:
                f.write(f"- {model}\n")
            f.write("\n")
            
            f.write("## 测试矩阵\n\n")
            f.write("| Prompt | 模型 | 状态 | 视频文件 | 分析结果 |\n")
            f.write("|--------|------|------|----------|----------|\n")
            for prompt in prompts:
                for model in models:
                    f.write(f"| {prompt.get('name', '')} | {model} | ⏳ 待测试 | - | - |\n")
            
            f.write("\n## 测试步骤\n\n")
            f.write("1. **生成视频**: 使用每个prompt在指定模型上生成视频\n")
            f.write("2. **命名规范**: 使用格式 `{prompt_id}_{model}_{timestamp}.mp4`\n")
            f.write("3. **组织文件**: 将视频文件放在 `prompt_test_results/videos/` 目录\n")
            f.write("4. **运行分析**: 使用 `analyze_prompt_tests.py` 批量分析所有视频\n")
            f.write("5. **查看报告**: 查看生成的Excel/CSV报告和对比分析\n\n")
            
            f.write("## 评估指标\n\n")
            metrics = self.config.get('analysis_metrics', [])
            for metric in metrics:
                f.write(f"- {metric}\n")
        
        print(f"✅ 测试计划已创建: {output_path}")
        return str(output_path)
    
    def create_video_mapping_template(self, output_path: Optional[str] = None) -> str:
        """
        创建视频文件映射模板（用于记录生成的视频文件）
        
        Args:
            output_path: 输出文件路径
            
        Returns:
            输出文件路径
        """
        if output_path is None:
            output_path = self.test_results_dir / "video_mapping.json"
        else:
            output_path = Path(output_path)
        
        prompts = self.list_prompts()
        models = self.config.get('models_to_test', [])
        
        mapping = {
            "description": "视频文件映射表 - 记录每个测试用例对应的视频文件",
            "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "videos": []
        }
        
        for prompt in prompts:
            for model in models:
                mapping["videos"].append({
                    "prompt_id": prompt.get('id', ''),
                    "prompt_name": prompt.get('name', ''),
                    "model": model,
                    "video_file": "",  # 待填写
                    "video_path": "",  # 待填写（完整路径）
                    "generated_date": "",  # 待填写
                    "status": "pending"  # pending, generated, analyzed
                })
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(mapping, f, indent=2, ensure_ascii=False)
        
        print(f"✅ 视频映射模板已创建: {output_path}")
        print(f"   请填写每个测试用例对应的视频文件路径")
        return str(output_path)
    
    def validate_video_mapping(self, mapping_path: str) -> Dict:
        """
        验证视频映射文件
        
        Args:
            mapping_path: 映射文件路径
            
        Returns:
            验证结果字典
        """
        mapping_path = Path(mapping_path)
        if not mapping_path.exists():
            return {
                'valid': False,
                'error': f'映射文件不存在: {mapping_path}'
            }
        
        with open(mapping_path, 'r', encoding='utf-8') as f:
            mapping = json.load(f)
        
        videos = mapping.get('videos', [])
        total = len(videos)
        generated = sum(1 for v in videos if v.get('status') == 'generated' and v.get('video_path'))
        analyzed = sum(1 for v in videos if v.get('status') == 'analyzed')
        
        # 检查文件是否存在
        missing_files = []
        for video in videos:
            video_path = video.get('video_path', '')
            if video_path and video.get('status') in ['generated', 'analyzed']:
                if not Path(video_path).exists():
                    missing_files.append({
                        'prompt_id': video.get('prompt_id'),
                        'model': video.get('model'),
                        'path': video_path
                    })
        
        return {
            'valid': True,
            'total': total,
            'generated': generated,
            'analyzed': analyzed,
            'pending': total - generated,
            'missing_files': missing_files,
            'completion_rate': (generated / total * 100) if total > 0 else 0
        }
    
    def print_summary(self):
        """打印测试配置摘要"""
        prompts = self.list_prompts()
        models = self.config.get('models_to_test', [])
        
        print("\n" + "="*70)
        print(f"Prompt测试配置摘要")
        print("="*70)
        print(f"测试名称: {self.config.get('test_name', '未命名')}")
        print(f"描述: {self.config.get('description', '')}")
        print(f"\nPrompt数量: {len(prompts)}")
        print(f"测试模型: {len(models)}")
        print(f"总测试用例: {len(prompts) * len(models)}")
        
        print(f"\n【Prompt列表】")
        for i, prompt in enumerate(prompts, 1):
            print(f"  {i}. {prompt.get('name', '未命名')} ({prompt.get('id', '')})")
            print(f"     类别: {prompt.get('category', '未分类')}")
            print(f"     难度: {prompt.get('difficulty', '未知')}")
        
        print(f"\n【测试模型】")
        for model in models:
            print(f"  - {model}")
        
        print("="*70 + "\n")


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("使用方法: python prompt_test_manager.py <命令> [选项]")
        print("\n命令:")
        print("  list                列出所有prompt")
        print("  plan                创建测试计划文档")
        print("  template            创建视频映射模板")
        print("  validate <路径>     验证视频映射文件")
        print("  summary             显示配置摘要")
        print("\n示例:")
        print("  python prompt_test_manager.py list")
        print("  python prompt_test_manager.py plan")
        print("  python prompt_test_manager.py template")
        print("  python prompt_test_manager.py validate prompt_test_results/video_mapping.json")
        sys.exit(1)
    
    command = sys.argv[1]
    
    try:
        manager = PromptTestManager()
        
        if command == "list":
            prompts = manager.list_prompts()
            print("\n" + "="*70)
            print("Prompt列表")
            print("="*70)
            for i, prompt in enumerate(prompts, 1):
                print(f"\n{i}. {prompt.get('name', '未命名')} (ID: {prompt.get('id', '')})")
                print(f"   Prompt: {prompt.get('prompt', '')}")
                print(f"   类别: {prompt.get('category', '未分类')}")
                print(f"   难度: {prompt.get('difficulty', '未知')}")
                print(f"   预期特征: {', '.join(prompt.get('expected_characteristics', []))}")
            print("="*70 + "\n")
        
        elif command == "plan":
            output = manager.create_test_plan()
            print(f"\n测试计划已创建: {output}")
        
        elif command == "template":
            output = manager.create_video_mapping_template()
            print(f"\n视频映射模板已创建: {output}")
            print("\n下一步:")
            print("1. 使用各个模型生成视频")
            print("2. 填写映射文件中的视频路径")
            print("3. 运行 analyze_prompt_tests.py 进行分析")
        
        elif command == "validate":
            if len(sys.argv) < 3:
                print("错误: 请指定映射文件路径", file=sys.stderr)
                sys.exit(1)
            mapping_path = sys.argv[2]
            result = manager.validate_video_mapping(mapping_path)
            if result['valid']:
                print("\n" + "="*70)
                print("视频映射验证结果")
                print("="*70)
                print(f"总测试用例: {result['total']}")
                print(f"已生成视频: {result['generated']}")
                print(f"已分析: {result['analyzed']}")
                print(f"待完成: {result['pending']}")
                print(f"完成率: {result['completion_rate']:.1f}%")
                if result['missing_files']:
                    print(f"\n⚠️  缺失文件 ({len(result['missing_files'])}):")
                    for missing in result['missing_files'][:10]:
                        print(f"  - {missing['prompt_id']} / {missing['model']}: {missing['path']}")
                    if len(result['missing_files']) > 10:
                        print(f"  ... 还有 {len(result['missing_files']) - 10} 个")
                print("="*70 + "\n")
            else:
                print(f"❌ 验证失败: {result.get('error', '未知错误')}", file=sys.stderr)
                sys.exit(1)
        
        elif command == "summary":
            manager.print_summary()
        
        else:
            print(f"未知命令: {command}", file=sys.stderr)
            sys.exit(1)
    
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()

