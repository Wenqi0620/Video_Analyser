# Prompt测试指南

本指南帮助你系统地测试10个不同的视频生成prompt，并使用本工具分析生成的视频质量。

## 📋 测试流程概览

1. **准备阶段**: 创建测试计划和配置
2. **生成阶段**: 使用各个模型生成视频
3. **组织阶段**: 整理视频文件并填写映射表
4. **分析阶段**: 批量分析所有视频
5. **对比阶段**: 查看对比报告和结论

## 🚀 快速开始

### 步骤1: 查看测试配置

```bash
# 查看所有prompt
python prompt_test_manager.py list

# 查看配置摘要
python prompt_test_manager.py summary
```

### 步骤2: 创建测试计划

```bash
# 创建测试计划文档
python prompt_test_manager.py plan

# 创建视频映射模板
python prompt_test_manager.py template
```

这会生成：
- `prompt_test_results/测试计划_YYYYMMDD_HHMMSS.md` - 详细的测试计划
- `prompt_test_results/video_mapping.json` - 视频文件映射模板

### 步骤3: 生成视频

使用各个视频生成模型（Gen-2, Pika, Runway等）生成视频：

1. 打开 `prompts_test_config.json` 查看所有prompt
2. 对每个prompt，在支持的模型上生成视频
3. 建议命名格式: `{prompt_id}_{model}_{timestamp}.mp4`
   - 例如: `prompt_01_Gen-2_20241224.mp4`

### 步骤4: 填写视频映射

编辑 `prompt_test_results/video_mapping.json`，填写每个测试用例的视频路径：

```json
{
  "videos": [
    {
      "prompt_id": "prompt_01",
      "prompt_name": "花朵绽放",
      "model": "Gen-2",
      "video_file": "prompt_01_Gen-2_20241224.mp4",
      "video_path": "/path/to/prompt_01_Gen-2_20241224.mp4",
      "generated_date": "2024-12-24",
      "status": "generated"
    }
  ]
}
```

### 步骤5: 验证映射文件

```bash
# 验证视频映射文件
python prompt_test_manager.py validate prompt_test_results/video_mapping.json
```

这会检查：
- 所有测试用例是否已填写
- 视频文件是否存在
- 完成进度

### 步骤6: 批量分析视频

```bash
# 分析所有视频（使用默认采样率5，加快速度）
python analyze_prompt_tests.py prompt_test_results/video_mapping.json

# 使用更低的采样率（更准确但更慢）
python analyze_prompt_tests.py prompt_test_results/video_mapping.json --sample-rate 3

# 指定输出目录
python analyze_prompt_tests.py prompt_test_results/video_mapping.json --output-dir my_results
```

### 步骤7: 查看分析报告

分析完成后，会在输出目录生成：

1. **JSON结果**: `prompt_test_results_YYYYMMDD_HHMMSS.json` - 完整的分析数据
2. **CSV报告**: `prompt_test_comparison_YYYYMMDD_HHMMSS.csv` - 可导入Excel
3. **Excel报告** (如果安装了pandas): `prompt_test_comparison_YYYYMMDD_HHMMSS.xlsx`
   - 包含多个工作表：
     - `全部结果`: 所有测试用例的详细数据
     - `Prompt对比`: 按prompt分组的统计
     - `模型对比`: 按模型分组的统计

## 📊 评估指标说明

分析报告包含以下关键指标：

### 综合评分（总分100分）

1. **FPS稳定性** (25分)
   - 评估帧率的稳定性
   - CV（变异系数）越小，分数越高

2. **时间戳抖动** (15分)
   - 评估时间戳的稳定性
   - 抖动百分比越小，分数越高

3. **重复帧** (15分)
   - 检测重复或近似重复的帧
   - 重复率越低，分数越高

4. **运动连续性** (25分)
   - 评估运动的平滑度
   - 连续性分数越高越好

5. **果冻效应** (10分)
   - 检测滚动快门失真
   - 失真分数越低越好

6. **视频质量** (10分)
   - 基于分辨率的评分
   - 4K=10分, 1080p=8分, 720p=5分

### 评级标准

- **优秀** (90-100分): 视频质量非常好
- **良好** (80-89分): 视频质量良好
- **一般** (70-79分): 视频质量一般
- **较差** (60-69分): 视频质量较差
- **很差** (<60分): 视频质量很差

## 🔍 研究建议

### 1. Prompt设计研究

**研究问题**:
- 哪些类型的prompt更容易生成高质量视频？
- 不同难度级别的prompt表现如何？
- 哪些prompt特征影响视频质量？

**分析方法**:
- 对比不同类别prompt的平均得分
- 分析难度与质量的关系
- 识别高质量prompt的共同特征

### 2. 模型对比研究

**研究问题**:
- 哪个模型在整体质量上表现最好？
- 不同模型在不同类型prompt上的表现如何？
- 模型的优势和劣势分别是什么？

**分析方法**:
- 查看"模型对比"工作表
- 按prompt类别分组对比
- 分析各模型在不同指标上的表现

### 3. Prompt-模型匹配研究

**研究问题**:
- 哪些prompt-模型组合表现最好？
- 是否存在特定prompt适合特定模型？
- 如何为不同prompt选择最佳模型？

**分析方法**:
- 找出每个prompt的最佳模型
- 分析prompt特征与模型表现的关联
- 建立prompt-模型匹配建议

### 4. 质量指标相关性研究

**研究问题**:
- 哪些指标最能预测整体质量？
- 指标之间是否存在相关性？
- 哪些指标对特定类型prompt更重要？

**分析方法**:
- 计算指标之间的相关系数
- 分析高分视频的共同特征
- 识别关键质量指标

### 5. 失败案例分析

**研究问题**:
- 哪些测试用例得分最低？为什么？
- 常见的问题类型有哪些？
- 如何改进低质量视频？

**分析方法**:
- 筛选低分视频（<70分）
- 分析失败原因
- 提出改进建议

## 📝 测试最佳实践

### 视频生成建议

1. **统一参数**: 尽量使用相同的生成参数（分辨率、时长等）
2. **多次生成**: 对关键prompt可以生成多个版本对比
3. **记录参数**: 在映射文件中记录生成参数
4. **质量控制**: 生成后先人工检查，排除明显失败的视频

### 文件组织建议

```
prompt_test_results/
├── videos/                    # 存放所有测试视频
│   ├── prompt_01_Gen-2.mp4
│   ├── prompt_01_Pika.mp4
│   └── ...
├── video_mapping.json         # 视频映射文件
├── 测试计划_*.md              # 测试计划文档
└── prompt_test_results_*.json # 分析结果
```

### 分析建议

1. **采样率选择**:
   - 短视频 (<30秒): `sample_rate=1` (最准确)
   - 中等视频 (30秒-2分钟): `sample_rate=3-5` (平衡)
   - 长视频 (>2分钟): `sample_rate=5-10` (快速)

2. **分批分析**: 如果视频很多，可以分批分析
3. **保存中间结果**: 分析过程较长，建议保存JSON结果

## 🎯 示例研究问题

基于10个prompt的测试，你可以研究：

1. **Prompt工程研究**
   - 关键词对质量的影响（如"cinematic", "uhd", "smooth"）
   - Prompt长度与质量的关系
   - 特定描述词的效果

2. **模型能力研究**
   - 各模型在不同场景类型上的表现
   - 模型对特定运动类型的处理能力
   - 模型的技术指标对比

3. **质量评估研究**
   - 客观指标与主观质量的关系
   - 哪些指标最能反映视频质量
   - 质量评估方法的有效性

4. **应用导向研究**
   - 不同应用场景的最佳prompt-模型组合
   - 成本-质量权衡分析
   - 实际应用建议

## 📚 相关文档

- `MOTION_QUALITY_GUIDE.md` - 运动质量分析详细说明
- `FPS_DYNAMICS_GUIDE.md` - FPS动态分析说明
- `FRAME_DYNAMICS_GUIDE.md` - 帧动态分析说明
- `BATCH_ANALYSIS_README.md` - 批量分析说明

## ❓ 常见问题

**Q: 如果某个模型不支持某个prompt怎么办？**
A: 在映射文件中将该测试用例的status设为"skipped"，或直接不填写video_path。

**Q: 可以只测试部分prompt吗？**
A: 可以，只需在映射文件中填写你想测试的视频即可。

**Q: 分析需要多长时间？**
A: 取决于视频数量和长度。一个1分钟的视频大约需要2-5分钟（sample_rate=5）。

**Q: 如何对比不同批次的结果？**
A: 可以合并多个JSON结果文件，或使用Excel的透视表功能。

## 🔄 更新测试配置

如果需要修改测试配置：

1. 编辑 `prompts_test_config.json`
2. 重新运行 `python prompt_test_manager.py plan` 生成新的测试计划
3. 更新 `video_mapping.json` 以匹配新的配置

---

**祝你测试顺利！** 🎬

