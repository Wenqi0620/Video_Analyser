#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prompt测试分析工具
基于video_mapping.json批量分析视频并生成对比报告
"""

import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import csv

# 导入分析器（从上级目录，即项目根目录）
_parent_dir = Path(__file__).parent.parent
if str(_parent_dir) not in sys.path:
    sys.path.insert(0, str(_parent_dir))
from video_analyzer import VideoAnalyzer

# Excel支持
try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False


def analyze_video_for_prompt_test(video_path: Path, sample_rate: int = 5) -> Dict:
    """
    分析单个视频（用于prompt测试）
    
    Args:
        video_path: 视频文件路径
        sample_rate: 采样率
        
    Returns:
        分析结果字典
    """
    print(f"\n{'='*80}")
    print(f"正在分析: {video_path.name}")
    print(f"{'='*80}")
    
    try:
        analyzer = VideoAnalyzer(str(video_path))
        
        # 1. 基础分析
        print("\n[1/4] 基础分析...")
        basic_result = analyzer.analyze()
        
        # 2. FPS动态分析
        print("\n[2/4] FPS动态分析...")
        fps_result = analyzer.analyze_fps_dynamics()
        
        # 3. 帧动态分析（使用采样加快速度）
        print("\n[3/4] 帧动态分析...")
        dynamics_result = analyzer.analyze_frame_dynamics(sample_rate=sample_rate)
        
        # 4. 运动质量分析（使用采样加快速度）
        print("\n[4/4] 运动质量分析...")
        motion_result = analyzer.analyze_motion_quality(sample_rate=sample_rate)
        
        # 计算综合评分
        score = calculate_overall_score(basic_result, fps_result, dynamics_result, motion_result)
        
        return {
            'success': True,
            'basic': basic_result,
            'fps_dynamics': fps_result,
            'frame_dynamics': dynamics_result,
            'motion_quality': motion_result,
            'overall_score': score
        }
        
    except Exception as e:
        print(f"❌ 分析失败: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return {
            'success': False,
            'error': str(e)
        }


def calculate_overall_score(basic: Dict, fps: Dict, dynamics: Dict, motion: Dict) -> Dict:
    """计算综合评分（与batch_analyze.py中的逻辑一致）"""
    scores = {}
    
    # 1. FPS稳定性评分 (0-25分)
    if 'overall_stats' in fps:
        fps_stats = fps['overall_stats']
        cv = (fps_stats.get('std_fps', 0) / fps_stats.get('mean_fps', 1) * 100) if fps_stats.get('mean_fps', 0) > 0 else 100
        fps_stability_score = max(0, 25 - cv * 0.5)
        scores['fps_stability'] = round(fps_stability_score, 2)
    else:
        scores['fps_stability'] = 0
    
    # 2. 时间戳抖动评分 (0-15分)
    if 'effective_fps_pts_jitter' in motion:
        pts_data = motion['effective_fps_pts_jitter']
        jitter_pct = pts_data.get('jitter_percentage', 100)
        pts_score = max(0, 15 - jitter_pct * 0.3)
        scores['pts_jitter'] = round(pts_score, 2)
    else:
        scores['pts_jitter'] = 0
    
    # 3. 重复帧评分 (0-15分)
    if 'duplicate_frame_ratio' in motion:
        dup_data = motion['duplicate_frame_ratio']
        dup_ratio = dup_data.get('total_duplicate_ratio', 1.0) * 100
        dup_score = max(0, 15 - dup_ratio * 3)
        scores['duplicate_frames'] = round(dup_score, 2)
    else:
        scores['duplicate_frames'] = 0
    
    # 4. 运动连续性评分 (0-25分)
    if 'motion_continuity' in motion:
        motion_data = motion['motion_continuity']
        continuity_score = motion_data.get('motion_continuity_score', 0) * 0.25
        scores['motion_continuity'] = round(continuity_score, 2)
    else:
        scores['motion_continuity'] = 0
    
    # 5. 果冻效应评分 (0-10分)
    if 'wobble_distortion' in motion:
        wobble_data = motion['wobble_distortion']
        wobble_score_val = wobble_data.get('wobble_distortion_score', 100)
        wobble_score = max(0, 10 - wobble_score_val * 0.1)
        scores['wobble'] = round(wobble_score, 2)
    else:
        scores['wobble'] = 0
    
    # 6. 视频质量基础分 (0-10分)
    if 'resolution' in basic:
        width = basic['resolution'].get('width', 0)
        height = basic['resolution'].get('height', 0)
        if width >= 3840 or height >= 2160:
            res_score = 10
        elif width >= 1920 or height >= 1080:
            res_score = 8
        elif width >= 1280 or height >= 720:
            res_score = 5
        else:
            res_score = 3
        scores['quality'] = res_score
    else:
        scores['quality'] = 0
    
    # 总分
    total_score = sum(scores.values())
    scores['total'] = round(total_score, 2)
    
    # 评级
    if total_score >= 90:
        scores['grade'] = '优秀'
    elif total_score >= 80:
        scores['grade'] = '良好'
    elif total_score >= 70:
        scores['grade'] = '一般'
    elif total_score >= 60:
        scores['grade'] = '较差'
    else:
        scores['grade'] = '很差'
    
    return scores


def load_video_mapping(mapping_path: str) -> Dict:
    """加载视频映射文件"""
    mapping_path = Path(mapping_path)
    if not mapping_path.exists():
        raise FileNotFoundError(f"映射文件不存在: {mapping_path}")
    
    with open(mapping_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def analyze_all_videos(mapping_path: str, sample_rate: int = 5, 
                      output_dir: Optional[str] = None) -> List[Dict]:
    """
    分析所有视频
    
    Args:
        mapping_path: 视频映射文件路径
        sample_rate: 采样率
        output_dir: 输出目录
        
    Returns:
        分析结果列表
    """
    mapping = load_video_mapping(mapping_path)
    videos = mapping.get('videos', [])
    
    if output_dir:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
    else:
        output_dir = Path("prompt_test_results")
        output_dir.mkdir(exist_ok=True)
    
    results = []
    success_count = 0
    error_count = 0
    
    print(f"\n{'='*80}")
    print(f"开始分析 {len(videos)} 个视频")
    print(f"{'='*80}\n")
    
    for i, video_info in enumerate(videos, 1):
        video_path_str = video_info.get('video_path', '')
        if not video_path_str:
            print(f"\n[{i}/{len(videos)}] ⏭️  跳过: {video_info.get('prompt_id')} / {video_info.get('model')} (未指定视频路径)")
            continue
        
        video_path = Path(video_path_str)
        if not video_path.exists():
            print(f"\n[{i}/{len(videos)}] ❌ 文件不存在: {video_path}")
            results.append({
                'prompt_id': video_info.get('prompt_id'),
                'prompt_name': video_info.get('prompt_name'),
                'model': video_info.get('model'),
                'video_path': str(video_path),
                'success': False,
                'error': '文件不存在'
            })
            error_count += 1
            continue
        
        print(f"\n[{i}/{len(videos)}] 分析: {video_info.get('prompt_name')} / {video_info.get('model')}")
        
        result = analyze_video_for_prompt_test(video_path, sample_rate=sample_rate)
        result.update({
            'prompt_id': video_info.get('prompt_id'),
            'prompt_name': video_info.get('prompt_name'),
            'model': video_info.get('model'),
            'video_path': str(video_path),
            'video_file': video_info.get('video_file', '')
        })
        
        results.append(result)
        
        if result.get('success'):
            success_count += 1
            score = result.get('overall_score', {}).get('total', 0)
            grade = result.get('overall_score', {}).get('grade', '')
            print(f"✅ 完成 - 总分: {score:.2f} ({grade})")
        else:
            error_count += 1
    
    print(f"\n{'='*80}")
    print(f"分析完成!")
    print(f"成功: {success_count}, 失败: {error_count}, 总计: {len(videos)}")
    print(f"{'='*80}\n")
    
    # 保存JSON结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_path = output_dir / f"prompt_test_results_{timestamp}.json"
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"✅ JSON结果已保存: {json_path}")
    
    return results


def create_comparison_report(results: List[Dict], output_dir: Path):
    """创建对比分析报告"""
    if not results:
        print("没有结果可生成报告", file=sys.stderr)
        return
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # 准备数据
    rows = []
    for result in results:
        if not result.get('success'):
            continue
        
        basic = result.get('basic', {})
        fps = result.get('fps_dynamics', {})
        motion = result.get('motion_quality', {})
        scores = result.get('overall_score', {})
        
        fps_stats = fps.get('overall_stats', {})
        pts_data = motion.get('effective_fps_pts_jitter', {})
        dup_data = motion.get('duplicate_frame_ratio', {})
        motion_data = motion.get('motion_continuity', {})
        wobble_data = motion.get('wobble_distortion', {})
        
        rows.append({
            'Prompt ID': result.get('prompt_id', ''),
            'Prompt名称': result.get('prompt_name', ''),
            '模型': result.get('model', ''),
            '视频文件': result.get('video_file', ''),
            '总分': scores.get('total', 0),
            '评级': scores.get('grade', ''),
            'FPS稳定性': scores.get('fps_stability', 0),
            '时间戳抖动': scores.get('pts_jitter', 0),
            '重复帧': scores.get('duplicate_frames', 0),
            '运动连续性': scores.get('motion_continuity', 0),
            '果冻效应': scores.get('wobble', 0),
            '视频质量': scores.get('quality', 0),
            '声明FPS': basic.get('fps', 0),
            '平均实际FPS': round(fps_stats.get('mean_fps', 0), 3),
            'FPS标准差': round(fps_stats.get('std_fps', 0), 3),
            'PTS抖动(%)': round(pts_data.get('jitter_percentage', 0), 2),
            '重复率(%)': round(dup_data.get('total_duplicate_ratio', 0) * 100, 2),
            '运动连续性分数': round(motion_data.get('motion_continuity_score', 0), 2),
            '失真分数': round(wobble_data.get('wobble_distortion_score', 0), 2),
        })
    
    # CSV报告
    csv_path = output_dir / f"prompt_test_comparison_{timestamp}.csv"
    if rows:
        with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        print(f"✅ CSV对比报告已保存: {csv_path}")
    
    # Excel报告（如果有pandas）
    if PANDAS_AVAILABLE and rows:
        excel_path = output_dir / f"prompt_test_comparison_{timestamp}.xlsx"
        df = pd.DataFrame(rows)
        
        # 按Prompt和总分排序
        df = df.sort_values(['Prompt ID', '总分'], ascending=[True, False])
        
        with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
            # 主表
            df.to_excel(writer, sheet_name='全部结果', index=False)
            
            # 按Prompt分组统计
            if 'Prompt ID' in df.columns and '总分' in df.columns:
                prompt_summary = []
                for prompt_id in df['Prompt ID'].unique():
                    prompt_df = df[df['Prompt ID'] == prompt_id]
                    prompt_summary.append({
                        'Prompt ID': prompt_id,
                        'Prompt名称': prompt_df['Prompt名称'].iloc[0] if len(prompt_df) > 0 else '',
                        '测试数量': len(prompt_df),
                        '平均总分': round(prompt_df['总分'].mean(), 2),
                        '最高分': round(prompt_df['总分'].max(), 2),
                        '最低分': round(prompt_df['总分'].min(), 2),
                        '最佳模型': prompt_df.loc[prompt_df['总分'].idxmax(), '模型'] if len(prompt_df) > 0 else '',
                    })
                
                summary_df = pd.DataFrame(prompt_summary)
                summary_df = summary_df.sort_values('平均总分', ascending=False)
                summary_df.to_excel(writer, sheet_name='Prompt对比', index=False)
            
            # 按模型分组统计
            if '模型' in df.columns and '总分' in df.columns:
                model_summary = []
                for model in df['模型'].unique():
                    model_df = df[df['模型'] == model]
                    model_summary.append({
                        '模型': model,
                        '测试数量': len(model_df),
                        '平均总分': round(model_df['总分'].mean(), 2),
                        '最高分': round(model_df['总分'].max(), 2),
                        '最低分': round(model_df['总分'].min(), 2),
                    })
                
                model_summary_df = pd.DataFrame(model_summary)
                model_summary_df = model_summary_df.sort_values('平均总分', ascending=False)
                model_summary_df.to_excel(writer, sheet_name='模型对比', index=False)
        
        print(f"✅ Excel对比报告已保存: {excel_path}")
    elif not PANDAS_AVAILABLE:
        print(f"\n提示: CSV文件已生成（可用Excel打开）。如需原生Excel格式，请运行: pip install pandas openpyxl")


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("使用方法: python analyze_prompt_tests.py <映射文件路径> [选项]")
        print("\n选项:")
        print("  --sample-rate N     采样率，默认5（每5帧分析一次，加快速度）")
        print("  --output-dir DIR    输出目录，默认 prompt_test_results")
        print("\n示例:")
        print("  python analyze_prompt_tests.py prompt_test_results/video_mapping.json")
        print("  python analyze_prompt_tests.py prompt_test_results/video_mapping.json --sample-rate 3")
        sys.exit(1)
    
    mapping_path = sys.argv[1]
    sample_rate = 5
    output_dir = None
    
    # 解析参数
    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == '--sample-rate' and i + 1 < len(sys.argv):
            sample_rate = int(sys.argv[i + 1])
            i += 2
        elif sys.argv[i] == '--output-dir' and i + 1 < len(sys.argv):
            output_dir = sys.argv[i + 1]
            i += 2
        else:
            i += 1
    
    try:
        # 分析所有视频
        results = analyze_all_videos(mapping_path, sample_rate=sample_rate, output_dir=output_dir)
        
        # 生成对比报告
        if output_dir:
            output_dir = Path(output_dir)
        else:
            output_dir = Path("prompt_test_results")
        
        create_comparison_report(results, output_dir)
        
        print("\n✅ 所有分析完成！")
        print(f"   结果保存在: {output_dir}")
        
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()

