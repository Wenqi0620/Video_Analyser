# 视频分析Web平台 - 中文文档

## 🌟 项目简介

这是一个功能完整的视频分析Web平台，集成了：
- 📹 **视频分析**: 自动分析视频的FPS、分辨率、运动质量等指标
- 📅 **日历集成**: 支持飞书、Outlook、iCalendar多种日历服务
- 🤖 **智能分类**: 自动识别视频生成模型（Gen-2、Pika、Haiper等）
- 📊 **数据可视化**: 实时展示分析结果和统计信息

## ✨ 核心功能

### 1. 视频分析功能
- ✅ 支持拖拽上传视频（MP4、AVI、MOV、MKV、WEBM）
- ✅ 基础信息分析（FPS、分辨率、时长、文件大小）
- ✅ FPS动态变化分析（按秒统计）
- ✅ 运动质量分析（4个核心指标）：
  - 有效FPS和时间戳抖动
  - 重复/近似重复帧比例
  - 运动连续性/Jerkiness评分
  - 果冻效应/滚动快门失真
- ✅ 自动归类到对应的生成模型
- ✅ 实时查看分析进度和结果

### 2. 日历集成功能
- ✅ **飞书日历**: 连接、查看、创建事件
- ✅ **Outlook日历**: 连接、查看、创建事件
- ✅ **iCalendar**: 支持通用.ics格式

### 3. 仪表盘功能
- ✅ 总视频数统计
- ✅ 已完成/处理中数量
- ✅ 模型分布统计
- ✅ 实时数据更新

## 🚀 快速开始

### 前置要求
- Python 3.11+
- Node.js 16+
- FFmpeg（视频分析需要）

### 安装FFmpeg

**macOS:**
```bash
brew install ffmpeg
```

**Ubuntu/Debian:**
```bash
sudo apt-get install ffmpeg
```

**Windows:**
从 https://ffmpeg.org/download.html 下载

### 步骤1: 安装后端依赖

```bash
cd Web_design
pip install -r requirements_web.txt
```

### 步骤2: 初始化数据库

```bash
python3 -c "from app.database import init_db; init_db()"
```

### 步骤3: 启动后端服务

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

后端将在 http://localhost:8000 启动

### 步骤4: 安装前端依赖（新终端窗口）

```bash
cd Web_design/frontend
npm install
```

### 步骤5: 启动前端开发服务器

```bash
npm run dev
```

前端将在 http://localhost:3000 启动

### 步骤6: 访问应用

打开浏览器访问: **http://localhost:3000**

## 📖 使用指南

### 上传和分析视频

1. 点击左侧菜单的"视频分析"
2. 在"上传视频"区域，拖拽视频文件或点击上传
3. 上传后，视频会自动开始分析
4. 在视频列表中查看分析进度
5. 分析完成后，点击"查看详情"查看完整分析结果

### 连接日历服务

#### 飞书日历
1. 访问 [飞书开放平台](https://open.feishu.cn/)
2. 创建应用，获取 App ID 和 App Secret
3. 在应用中启用"日历"权限
4. 在Web界面中填入凭证并连接

#### Outlook日历
1. 访问 [Azure Portal](https://portal.azure.com/)
2. 注册应用，获取 Client ID、Client Secret 和 Tenant ID
3. 配置API权限：`Calendars.ReadWrite`
4. 在Web界面中填入凭证并连接

### 查看日历事件

1. 连接日历后，点击"刷新事件"按钮
2. 在事件列表中查看所有日历事件
3. 点击"创建事件"可以创建新的日历事件

## 🏗️ 技术架构

### 后端技术栈
- **FastAPI**: 现代Python Web框架，自动生成API文档
- **SQLAlchemy**: ORM数据库操作
- **OpenCV**: 视频处理和图像分析
- **FFmpeg**: 视频元数据提取
- **icalendar**: iCalendar格式解析
- **msal**: Microsoft认证库

### 前端技术栈
- **React 18**: 用户界面框架
- **Ant Design**: 企业级UI组件库
- **Vite**: 快速的前端构建工具
- **Axios**: HTTP客户端
- **React Router**: 单页应用路由

### 数据库
- **SQLite**: 默认数据库（开发环境）
- **PostgreSQL**: 支持（生产环境）

## 📁 项目结构

```
Web_design/
├── app/                    # 后端核心代码
│   ├── main.py            # FastAPI主应用
│   ├── database.py        # 数据库配置
│   ├── models.py          # 数据模型
│   ├── calendar_integration.py  # 日历集成
│   └── video_classifier.py      # 视频分类器
│
├── frontend/               # 前端React应用
│   ├── src/
│   │   ├── components/   # React组件
│   │   ├── services/      # API服务
│   │   └── App.jsx        # 主应用
│   └── package.json
│
├── requirements_web.txt    # Python依赖
├── Dockerfile            # Docker配置
├── docker-compose.yml    # Docker Compose配置
└── README.md             # 完整文档
```

详细结构说明请查看: [项目结构说明.md](项目结构说明.md)

## 🔧 配置说明

### 环境变量

创建 `.env` 文件（可选）:

```bash
# 数据库
DATABASE_URL=sqlite:///./video_analysis.db

# 飞书日历（可选）
FEISHU_APP_ID=your_app_id
FEISHU_APP_SECRET=your_app_secret

# Outlook日历（可选）
OUTLOOK_CLIENT_ID=your_client_id
OUTLOOK_CLIENT_SECRET=your_client_secret
OUTLOOK_TENANT_ID=your_tenant_id
```

### API端点

主要API端点：
- `POST /api/videos/upload` - 上传视频
- `GET /api/videos` - 获取视频列表
- `GET /api/videos/{video_id}` - 获取视频详情
- `GET /api/models` - 获取模型列表
- `POST /api/calendar/feishu/connect` - 连接飞书日历
- `POST /api/calendar/outlook/connect` - 连接Outlook日历
- `GET /api/calendar/events` - 获取日历事件
- `POST /api/calendar/events` - 创建日历事件

完整API文档: http://localhost:8000/docs

## 🐳 Docker部署

### 使用Docker Compose

```bash
cd Web_design
docker-compose up -d
```

### 手动构建

```bash
docker build -t video-analysis-platform .
docker run -p 8000:8000 video-analysis-platform
```

## 📚 更多文档

- [快速开始指南](QUICK_START.md) - 5分钟快速启动
- [部署指南](DEPLOYMENT_GUIDE.md) - 生产环境部署详细说明
- [项目结构说明](项目结构说明.md) - 详细的目录结构说明

## ❓ 常见问题

### Q: 视频分析失败怎么办？

**检查以下几点：**
1. 确保安装了FFmpeg
2. 确保安装了OpenCV: `pip install opencv-python`
3. 查看后端日志获取详细错误信息
4. 检查视频文件格式是否支持

### Q: 前端无法连接后端？

**确保：**
1. 后端服务正在运行（http://localhost:8000）
2. 检查浏览器控制台是否有CORS错误
3. 确认后端CORS配置允许前端域名

### Q: 如何增加上传文件大小限制？

在 `app/main.py` 中修改FastAPI配置，或使用Nginx等反向代理配置。

### Q: 数据库可以换成PostgreSQL吗？

可以，修改 `app/database.py` 中的 `DATABASE_URL`，并安装PostgreSQL驱动：
```bash
pip install psycopg2-binary
```

## 🎯 开发计划

- [ ] 支持更多视频格式
- [ ] 批量视频分析
- [ ] 视频对比功能
- [ ] 导出分析报告（PDF/Excel）
- [ ] 用户认证和权限管理
- [ ] 更多日历提供商支持

## 📄 许可证

MIT License

## 🤝 贡献

欢迎提交Issue和Pull Request！

---

**需要帮助？** 查看文档或提交Issue。

